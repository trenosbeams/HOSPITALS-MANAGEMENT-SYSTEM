import { createClient } from "@supabase/supabase-js"

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!

export const supabase = createClient(supabaseUrl, supabaseAnonKey)

// Types for our database tables
export interface User {
  id: string
  email: string
  role: "patient" | "doctor" | "admin"
  full_name: string
  phone?: string
  created_at: string
  updated_at: string
}

export interface Patient {
  id: string
  user_id: string
  date_of_birth?: string
  gender?: "male" | "female"
  address?: string
  emergency_contact?: string
  emergency_phone?: string
  blood_type?: string
  allergies?: string
  created_at: string
  updated_at: string
  user?: User
}

export interface Doctor {
  id: string
  user_id: string
  specialty: string
  license_number: string
  experience_years?: number
  education?: string
  consultation_fee?: number
  is_available: boolean
  created_at: string
  updated_at: string
  user?: User
}

export interface Appointment {
  id: string
  patient_id: string
  doctor_id: string
  appointment_date: string
  appointment_time: string
  duration_minutes: number
  status: "pending" | "confirmed" | "in-progress" | "completed" | "cancelled"
  notes?: string
  created_at: string
  updated_at: string
  patient?: Patient
  doctor?: Doctor
}

export interface MedicalRecord {
  id: string
  patient_id: string
  doctor_id: string
  appointment_id?: string
  diagnosis?: string
  symptoms?: string
  treatment?: string
  prescription?: string
  notes?: string
  visit_date: string
  created_at: string
  updated_at: string
  patient?: Patient
  doctor?: Doctor
}

export interface Payment {
  id: string
  appointment_id: string
  patient_id: string
  amount: number
  payment_method: "bank_transfer" | "qris" | "cash" | "insurance"
  payment_status: "pending" | "completed" | "failed" | "refunded"
  transaction_id?: string
  payment_date?: string
  created_at: string
  updated_at: string
}
