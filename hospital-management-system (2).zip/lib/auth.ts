import { supabase } from "./supabase"
import bcrypt from "bcryptjs"

export interface LoginCredentials {
  email: string
  password: string
  role: "patient" | "doctor" | "admin"
}

export interface RegisterData {
  email: string
  password: string
  fullName: string
  phone?: string
  dateOfBirth?: string
  gender?: "male" | "female"
  address?: string
  emergencyContact?: string
  emergencyPhone?: string
}

export async function loginUser(credentials: LoginCredentials) {
  try {
    // Get user by email and role
    const { data: user, error } = await supabase
      .from("users")
      .select("*")
      .eq("email", credentials.email)
      .eq("role", credentials.role)
      .single()

    if (error || !user) {
      throw new Error("Invalid credentials")
    }

    // Verify password (in production, use proper password hashing)
    const isValidPassword = await bcrypt.compare(credentials.password, user.password_hash)

    if (!isValidPassword) {
      throw new Error("Invalid credentials")
    }

    // Sign in with Supabase Auth
    const { data: authData, error: authError } = await supabase.auth.signInWithPassword({
      email: credentials.email,
      password: credentials.password,
    })

    if (authError) {
      throw authError
    }

    return {
      user: {
        id: user.id,
        email: user.email,
        role: user.role,
        name: user.full_name,
      },
      session: authData.session,
    }
  } catch (error) {
    console.error("Login error:", error)
    throw error
  }
}

export async function registerPatient(data: RegisterData) {
  try {
    // Hash password
    const passwordHash = await bcrypt.hash(data.password, 10)

    // Create user in Supabase Auth
    const { data: authData, error: authError } = await supabase.auth.signUp({
      email: data.email,
      password: data.password,
    })

    if (authError) {
      throw authError
    }

    // Create user record
    const { data: user, error: userError } = await supabase
      .from("users")
      .insert({
        id: authData.user?.id,
        email: data.email,
        password_hash: passwordHash,
        role: "patient",
        full_name: data.fullName,
        phone: data.phone,
      })
      .select()
      .single()

    if (userError) {
      throw userError
    }

    // Create patient record
    const { data: patient, error: patientError } = await supabase
      .from("patients")
      .insert({
        user_id: user.id,
        date_of_birth: data.dateOfBirth,
        gender: data.gender,
        address: data.address,
        emergency_contact: data.emergencyContact,
        emergency_phone: data.emergencyPhone,
      })
      .select()
      .single()

    if (patientError) {
      throw patientError
    }

    return {
      user: {
        id: user.id,
        email: user.email,
        role: user.role,
        name: user.full_name,
      },
      session: authData.session,
    }
  } catch (error) {
    console.error("Registration error:", error)
    throw error
  }
}

export async function getCurrentUser() {
  try {
    const {
      data: { session },
    } = await supabase.auth.getSession()

    if (!session) {
      return null
    }

    const { data: user, error } = await supabase.from("users").select("*").eq("id", session.user.id).single()

    if (error) {
      throw error
    }

    return {
      id: user.id,
      email: user.email,
      role: user.role,
      name: user.full_name,
    }
  } catch (error) {
    console.error("Get current user error:", error)
    return null
  }
}

export async function logoutUser() {
  try {
    const { error } = await supabase.auth.signOut()
    if (error) {
      throw error
    }
  } catch (error) {
    console.error("Logout error:", error)
    throw error
  }
}
