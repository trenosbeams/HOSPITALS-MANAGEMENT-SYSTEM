"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Calendar, FileText, CreditCard, Clock, User, LogOut, Bell } from "lucide-react"
import { useRouter } from "next/navigation"

export default function PatientDashboard() {
  const [user, setUser] = useState<any>(null)
  const router = useRouter()

  useEffect(() => {
    const userData = localStorage.getItem("user")
    if (userData) {
      setUser(JSON.parse(userData))
    } else {
      router.push("/login")
    }
  }, [router])

  const handleLogout = () => {
    localStorage.removeItem("user")
    router.push("/")
  }

  if (!user) return null

  const upcomingAppointments = [
    {
      id: 1,
      doctor: "Dr. Sarah Johnson",
      specialty: "Kardiologi",
      date: "2024-01-15",
      time: "10:00",
      status: "confirmed",
    },
    {
      id: 2,
      doctor: "Dr. Michael Chen",
      specialty: "Dermatologi",
      date: "2024-01-20",
      time: "14:30",
      status: "pending",
    },
  ]

  const recentRecords = [
    {
      id: 1,
      date: "2024-01-10",
      doctor: "Dr. Sarah Johnson",
      diagnosis: "Pemeriksaan Rutin Jantung",
      status: "completed",
    },
    {
      id: 2,
      date: "2024-01-05",
      doctor: "Dr. Lisa Wong",
      diagnosis: "Konsultasi Gizi",
      status: "completed",
    },
  ]

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <img src="/images/hospital-logo.png" alt="PERSADA SARI HUSNA Medical Center" className="h-10 w-10" />
            <h1 className="text-2xl font-bold text-gray-900">Dashboard Pasien</h1>
          </div>
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="sm">
              <Bell className="h-4 w-4" />
            </Button>
            <div className="flex items-center space-x-2">
              <User className="h-5 w-5 text-gray-600" />
              <span className="text-sm font-medium">{user.name}</span>
            </div>
            <Button variant="outline" size="sm" onClick={handleLogout}>
              <LogOut className="h-4 w-4 mr-2" />
              Keluar
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-2">Selamat datang, {user.name}!</h2>
          <p className="text-gray-600">Kelola jadwal konsultasi dan akses rekam medis Anda dengan mudah</p>
        </div>

        {/* Quick Actions */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <Card
            className="hover:shadow-lg transition-shadow cursor-pointer"
            onClick={() => router.push("/patient/appointments")}
          >
            <CardHeader className="pb-3">
              <Calendar className="h-8 w-8 text-blue-600 mb-2" />
              <CardTitle className="text-lg">Buat Janji</CardTitle>
              <CardDescription>Jadwalkan konsultasi dengan dokter</CardDescription>
            </CardHeader>
          </Card>

          <Card
            className="hover:shadow-lg transition-shadow cursor-pointer"
            onClick={() => router.push("/patient/medical-records")}
          >
            <CardHeader className="pb-3">
              <FileText className="h-8 w-8 text-green-600 mb-2" />
              <CardTitle className="text-lg">Rekam Medis</CardTitle>
              <CardDescription>Lihat riwayat kesehatan Anda</CardDescription>
            </CardHeader>
          </Card>

          <Card
            className="hover:shadow-lg transition-shadow cursor-pointer"
            onClick={() => router.push("/patient/payments")}
          >
            <CardHeader className="pb-3">
              <CreditCard className="h-8 w-8 text-purple-600 mb-2" />
              <CardTitle className="text-lg">Pembayaran</CardTitle>
              <CardDescription>Bayar tagihan medis</CardDescription>
            </CardHeader>
          </Card>

          <Card
            className="hover:shadow-lg transition-shadow cursor-pointer"
            onClick={() => router.push("/patient/history")}
          >
            <CardHeader className="pb-3">
              <Clock className="h-8 w-8 text-orange-600 mb-2" />
              <CardTitle className="text-lg">Riwayat</CardTitle>
              <CardDescription>Lihat riwayat kunjungan</CardDescription>
            </CardHeader>
          </Card>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Upcoming Appointments */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Calendar className="h-5 w-5 mr-2" />
                Jadwal Konsultasi Mendatang
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {upcomingAppointments.map((appointment) => (
                  <div key={appointment.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div>
                      <h4 className="font-semibold">{appointment.doctor}</h4>
                      <p className="text-sm text-gray-600">{appointment.specialty}</p>
                      <p className="text-sm text-gray-500">
                        {appointment.date} • {appointment.time}
                      </p>
                    </div>
                    <Badge variant={appointment.status === "confirmed" ? "default" : "secondary"}>
                      {appointment.status === "confirmed" ? "Dikonfirmasi" : "Menunggu"}
                    </Badge>
                  </div>
                ))}
                <Button variant="outline" className="w-full" onClick={() => router.push("/patient/appointments")}>
                  Lihat Semua Jadwal
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Recent Medical Records */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <FileText className="h-5 w-5 mr-2" />
                Rekam Medis Terbaru
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentRecords.map((record) => (
                  <div key={record.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div>
                      <h4 className="font-semibold">{record.diagnosis}</h4>
                      <p className="text-sm text-gray-600">{record.doctor}</p>
                      <p className="text-sm text-gray-500">{record.date}</p>
                    </div>
                    <Badge variant="outline">Selesai</Badge>
                  </div>
                ))}
                <Button variant="outline" className="w-full" onClick={() => router.push("/patient/medical-records")}>
                  Lihat Semua Rekam Medis
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Health Summary */}
        <Card className="mt-8">
          <CardHeader>
            <CardTitle>Ringkasan Kesehatan</CardTitle>
            <CardDescription>Informasi kesehatan terkini berdasarkan pemeriksaan terakhir</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-4 gap-6">
              <div className="text-center p-4 bg-blue-50 rounded-lg">
                <h3 className="text-2xl font-bold text-blue-600">120/80</h3>
                <p className="text-sm text-gray-600">Tekanan Darah</p>
                <p className="text-xs text-green-600">Normal</p>
              </div>
              <div className="text-center p-4 bg-green-50 rounded-lg">
                <h3 className="text-2xl font-bold text-green-600">72</h3>
                <p className="text-sm text-gray-600">Detak Jantung</p>
                <p className="text-xs text-green-600">Normal</p>
              </div>
              <div className="text-center p-4 bg-purple-50 rounded-lg">
                <h3 className="text-2xl font-bold text-purple-600">65</h3>
                <p className="text-sm text-gray-600">Berat Badan (kg)</p>
                <p className="text-xs text-green-600">Ideal</p>
              </div>
              <div className="text-center p-4 bg-orange-50 rounded-lg">
                <h3 className="text-2xl font-bold text-orange-600">22.5</h3>
                <p className="text-sm text-gray-600">BMI</p>
                <p className="text-xs text-green-600">Normal</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
