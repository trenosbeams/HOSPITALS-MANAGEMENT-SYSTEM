"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { FileText, ArrowLeft, Eye, Download, Calendar, User } from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"

export default function PatientMedicalRecords() {
  const [user, setUser] = useState<any>(null)
  const [medicalRecords, setMedicalRecords] = useState<any[]>([])
  const [selectedRecord, setSelectedRecord] = useState<any>(null)
  const router = useRouter()

  useEffect(() => {
    const userData = localStorage.getItem("user")
    if (userData) {
      const parsedUser = JSON.parse(userData)
      if (parsedUser.role !== "patient") {
        router.push("/login")
      } else {
        setUser(parsedUser)
        loadMedicalRecords()
      }
    } else {
      router.push("/login")
    }
  }, [router])

  const loadMedicalRecords = () => {
    // Mock data - replace with actual API call
    const mockRecords = [
      {
        id: 1,
        date: "2024-01-10",
        doctor: "Dr. Sarah Johnson",
        specialty: "Kardiologi",
        diagnosis: "Hipertensi Stadium 1",
        symptoms: "Sakit kepala, pusing, tekanan darah tinggi",
        treatment: "Perubahan gaya hidup, diet rendah garam",
        prescription: "Amlodipine 5mg 1x sehari, Lisinopril 10mg 1x sehari",
        notes: "Kontrol tekanan darah setiap 2 minggu. Hindari makanan tinggi garam.",
        vitalSigns: {
          bloodPressure: "150/90 mmHg",
          heartRate: "85 bpm",
          temperature: "36.5°C",
          weight: "70 kg",
        },
      },
      {
        id: 2,
        date: "2024-01-05",
        doctor: "Dr. Lisa Wong",
        specialty: "Gizi",
        diagnosis: "Konsultasi Gizi Sehat",
        symptoms: "Ingin menurunkan berat badan",
        treatment: "Program diet seimbang dan olahraga teratur",
        prescription: "Multivitamin 1x sehari",
        notes: "Target penurunan berat badan 5kg dalam 3 bulan. Konsultasi ulang setiap bulan.",
        vitalSigns: {
          weight: "75 kg",
          height: "165 cm",
          bmi: "27.5",
        },
      },
      {
        id: 3,
        date: "2023-12-20",
        doctor: "Dr. Michael Chen",
        specialty: "Dermatologi",
        diagnosis: "Dermatitis Atopik",
        symptoms: "Gatal-gatal, kulit kering, kemerahan",
        treatment: "Pelembab khusus, hindari pemicu alergi",
        prescription: "Hydrocortisone cream 2x sehari, Cetirizine 10mg 1x sehari",
        notes: "Gunakan sabun bebas pewangi. Hindari stress dan cuaca panas.",
        vitalSigns: {
          temperature: "36.8°C",
        },
      },
    ]
    setMedicalRecords(mockRecords)
  }

  const downloadRecord = (record: any) => {
    // Mock download functionality
    const content = `
REKAM MEDIS ELEKTRONIK
PT Cipta Hospital Indonesia

Tanggal: ${record.date}
Dokter: ${record.doctor} (${record.specialty})
Pasien: ${user.name}

DIAGNOSIS: ${record.diagnosis}

KELUHAN: ${record.symptoms}

PENGOBATAN: ${record.treatment}

RESEP: ${record.prescription}

CATATAN: ${record.notes}

TANDA VITAL:
${Object.entries(record.vitalSigns)
  .map(([key, value]) => `${key}: ${value}`)
  .join("\n")}
    `

    const blob = new Blob([content], { type: "text/plain" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `rekam-medis-${record.date}.txt`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  if (!user) return null

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="sm" asChild>
              <Link href="/patient/dashboard">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Kembali
              </Link>
            </Button>
            <h1 className="text-2xl font-bold text-gray-900">Rekam Medis</h1>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Medical Records List */}
        <div className="space-y-6">
          {medicalRecords.map((record) => (
            <Card key={record.id}>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="flex items-center">
                      <FileText className="h-5 w-5 mr-2" />
                      {record.diagnosis}
                    </CardTitle>
                    <CardDescription>
                      {record.doctor} • {record.specialty}
                    </CardDescription>
                  </div>
                  <Badge variant="outline">{new Date(record.date).toLocaleDateString("id-ID")}</Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-4 mb-4">
                  <div className="flex items-center space-x-2">
                    <Calendar className="h-4 w-4 text-gray-500" />
                    <span>
                      {new Date(record.date).toLocaleDateString("id-ID", {
                        weekday: "long",
                        year: "numeric",
                        month: "long",
                        day: "numeric",
                      })}
                    </span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <User className="h-4 w-4 text-gray-500" />
                    <span>{record.doctor}</span>
                  </div>
                </div>

                <div className="space-y-3">
                  <div>
                    <h4 className="font-semibold text-sm text-gray-700">Keluhan:</h4>
                    <p className="text-sm text-gray-600">{record.symptoms}</p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-sm text-gray-700">Pengobatan:</h4>
                    <p className="text-sm text-gray-600">{record.treatment}</p>
                  </div>
                </div>

                <div className="flex justify-end space-x-2 mt-4">
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button variant="outline" size="sm" onClick={() => setSelectedRecord(record)}>
                        <Eye className="h-4 w-4 mr-2" />
                        Lihat Detail
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="sm:max-w-[600px]">
                      <DialogHeader>
                        <DialogTitle>Detail Rekam Medis</DialogTitle>
                        <DialogDescription>
                          {selectedRecord?.date} • {selectedRecord?.doctor}
                        </DialogDescription>
                      </DialogHeader>
                      {selectedRecord && (
                        <div className="space-y-4">
                          <div>
                            <h4 className="font-semibold text-sm text-gray-700 mb-1">Diagnosis:</h4>
                            <p className="text-sm">{selectedRecord.diagnosis}</p>
                          </div>
                          <div>
                            <h4 className="font-semibold text-sm text-gray-700 mb-1">Keluhan:</h4>
                            <p className="text-sm">{selectedRecord.symptoms}</p>
                          </div>
                          <div>
                            <h4 className="font-semibold text-sm text-gray-700 mb-1">Pengobatan:</h4>
                            <p className="text-sm">{selectedRecord.treatment}</p>
                          </div>
                          <div>
                            <h4 className="font-semibold text-sm text-gray-700 mb-1">Resep:</h4>
                            <p className="text-sm">{selectedRecord.prescription}</p>
                          </div>
                          <div>
                            <h4 className="font-semibold text-sm text-gray-700 mb-1">Catatan:</h4>
                            <p className="text-sm">{selectedRecord.notes}</p>
                          </div>
                          <div>
                            <h4 className="font-semibold text-sm text-gray-700 mb-1">Tanda Vital:</h4>
                            <div className="grid grid-cols-2 gap-2 text-sm">
                              {Object.entries(selectedRecord.vitalSigns).map(([key, value]) => (
                                <div key={key} className="flex justify-between">
                                  <span className="capitalize">{key.replace(/([A-Z])/g, " $1")}:</span>
                                  <span>{value}</span>
                                </div>
                              ))}
                            </div>
                          </div>
                        </div>
                      )}
                    </DialogContent>
                  </Dialog>
                  <Button size="sm" onClick={() => downloadRecord(record)}>
                    <Download className="h-4 w-4 mr-2" />
                    Download
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}

          {medicalRecords.length === 0 && (
            <Card>
              <CardContent className="text-center py-12">
                <FileText className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Belum Ada Rekam Medis</h3>
                <p className="text-gray-600 mb-4">
                  Rekam medis akan muncul setelah Anda melakukan konsultasi dengan dokter.
                </p>
                <Button asChild>
                  <Link href="/patient/appointments">Buat Janji Konsultasi</Link>
                </Button>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}
