"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Clock, ArrowLeft, Eye, Calendar, User, FileText } from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"

export default function PatientHistory() {
  const [user, setUser] = useState<any>(null)
  const [history, setHistory] = useState<any[]>([])
  const [selectedVisit, setSelectedVisit] = useState<any>(null)
  const router = useRouter()

  useEffect(() => {
    const userData = localStorage.getItem("user")
    if (userData) {
      const parsedUser = JSON.parse(userData)
      if (parsedUser.role !== "patient") {
        router.push("/login")
      } else {
        setUser(parsedUser)
        loadHistory()
      }
    } else {
      router.push("/login")
    }
  }, [router])

  const loadHistory = () => {
    // Mock data - replace with actual API call
    const mockHistory = [
      {
        id: 1,
        date: "2024-01-10",
        time: "10:00",
        doctor: {
          name: "Dr. Sarah Johnson",
          specialty: "Kardiologi",
          photo: "/placeholder.svg?height=40&width=40",
        },
        type: "Konsultasi",
        status: "completed",
        diagnosis: "Hipertensi Stadium 1",
        symptoms: "Sakit kepala, pusing, tekanan darah tinggi",
        treatment: "Perubahan gaya hidup, diet rendah garam",
        prescription: "Amlodipine 5mg 1x sehari, Lisinopril 10mg 1x sehari",
        notes: "Kontrol tekanan darah setiap 2 minggu. Hindari makanan tinggi garam.",
        vitalSigns: {
          bloodPressure: "150/90 mmHg",
          heartRate: "85 bpm",
          temperature: "36.5°C",
          weight: "70 kg",
        },
        cost: 500000,
        paymentStatus: "paid",
      },
      {
        id: 2,
        date: "2024-01-05",
        time: "14:30",
        doctor: {
          name: "Dr. Lisa Wong",
          specialty: "Gizi",
          photo: "/placeholder.svg?height=40&width=40",
        },
        type: "Konsultasi",
        status: "completed",
        diagnosis: "Konsultasi Gizi Sehat",
        symptoms: "Ingin menurunkan berat badan",
        treatment: "Program diet seimbang dan olahraga teratur",
        prescription: "Multivitamin 1x sehari",
        notes: "Target penurunan berat badan 5kg dalam 3 bulan. Konsultasi ulang setiap bulan.",
        vitalSigns: {
          weight: "75 kg",
          height: "165 cm",
          bmi: "27.5",
        },
        cost: 350000,
        paymentStatus: "paid",
      },
      {
        id: 3,
        date: "2023-12-20",
        time: "09:00",
        doctor: {
          name: "Dr. Michael Chen",
          specialty: "Dermatologi",
          photo: "/placeholder.svg?height=40&width=40",
        },
        type: "Pemeriksaan",
        status: "completed",
        diagnosis: "Dermatitis Atopik",
        symptoms: "Gatal-gatal, kulit kering, kemerahan",
        treatment: "Pelembab khusus, hindari pemicu alergi",
        prescription: "Hydrocortisone cream 2x sehari, Cetirizine 10mg 1x sehari",
        notes: "Gunakan sabun bebas pewangi. Hindari stress dan cuaca panas.",
        vitalSigns: {
          temperature: "36.8°C",
        },
        cost: 400000,
        paymentStatus: "paid",
      },
      {
        id: 4,
        date: "2023-11-15",
        time: "11:00",
        doctor: {
          name: "Dr. Ahmad Rizki",
          specialty: "Penyakit Dalam",
          photo: "/placeholder.svg?height=40&width=40",
        },
        type: "Pemeriksaan Rutin",
        status: "completed",
        diagnosis: "Pemeriksaan Kesehatan Umum",
        symptoms: "Check-up rutin tahunan",
        treatment: "Lanjutkan gaya hidup sehat",
        prescription: "Tidak ada",
        notes: "Kondisi kesehatan baik. Lanjutkan pola hidup sehat dan olahraga teratur.",
        vitalSigns: {
          bloodPressure: "120/80 mmHg",
          heartRate: "72 bpm",
          temperature: "36.7°C",
          weight: "68 kg",
        },
        cost: 450000,
        paymentStatus: "paid",
      },
    ]
    setHistory(mockHistory)
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "default"
      case "cancelled":
        return "destructive"
      default:
        return "outline"
    }
  }

  const getStatusText = (status: string) => {
    switch (status) {
      case "completed":
        return "Selesai"
      case "cancelled":
        return "Dibatalkan"
      default:
        return status
    }
  }

  const getPaymentStatusColor = (status: string) => {
    return status === "paid" ? "default" : "secondary"
  }

  const getPaymentStatusText = (status: string) => {
    return status === "paid" ? "Lunas" : "Belum Bayar"
  }

  if (!user) return null

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="sm" asChild>
              <Link href="/patient/dashboard">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Kembali
              </Link>
            </Button>
            <h1 className="text-2xl font-bold text-gray-900">Riwayat Kunjungan</h1>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Summary Stats */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Total Kunjungan</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{history.length}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Kunjungan Selesai</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{history.filter((h) => h.status === "completed").length}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Total Biaya</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                Rp {history.reduce((sum, h) => sum + h.cost, 0).toLocaleString()}
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Kunjungan Terakhir</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {history.length > 0 ? new Date(history[0].date).toLocaleDateString("id-ID") : "-"}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* History List */}
        <div className="space-y-6">
          {history.map((visit) => (
            <Card key={visit.id}>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                      <User className="h-6 w-6 text-blue-600" />
                    </div>
                    <div>
                      <CardTitle className="flex items-center">{visit.doctor.name}</CardTitle>
                      <CardDescription>
                        {visit.doctor.specialty} • {visit.type}
                      </CardDescription>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Badge variant={getStatusColor(visit.status)}>{getStatusText(visit.status)}</Badge>
                    <Badge variant={getPaymentStatusColor(visit.paymentStatus)}>
                      {getPaymentStatusText(visit.paymentStatus)}
                    </Badge>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-3 gap-4 mb-4">
                  <div className="flex items-center space-x-2">
                    <Calendar className="h-4 w-4 text-gray-500" />
                    <span>
                      {new Date(visit.date).toLocaleDateString("id-ID", {
                        weekday: "long",
                        year: "numeric",
                        month: "long",
                        day: "numeric",
                      })}
                    </span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Clock className="h-4 w-4 text-gray-500" />
                    <span>{visit.time}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="text-sm text-gray-600">Biaya:</span>
                    <span className="font-semibold">Rp {visit.cost.toLocaleString()}</span>
                  </div>
                </div>

                <div className="space-y-2 mb-4">
                  <div>
                    <span className="text-sm font-semibold text-gray-700">Diagnosis: </span>
                    <span className="text-sm">{visit.diagnosis}</span>
                  </div>
                  <div>
                    <span className="text-sm font-semibold text-gray-700">Keluhan: </span>
                    <span className="text-sm text-gray-600">{visit.symptoms}</span>
                  </div>
                </div>

                <div className="flex justify-end space-x-2">
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button variant="outline" size="sm" onClick={() => setSelectedVisit(visit)}>
                        <Eye className="h-4 w-4 mr-2" />
                        Lihat Detail
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="sm:max-w-[700px]">
                      <DialogHeader>
                        <DialogTitle>Detail Kunjungan</DialogTitle>
                        <DialogDescription>
                          {selectedVisit?.date} • {selectedVisit?.doctor.name}
                        </DialogDescription>
                      </DialogHeader>
                      {selectedVisit && (
                        <div className="space-y-6">
                          {/* Visit Info */}
                          <div className="grid md:grid-cols-2 gap-4">
                            <div>
                              <h4 className="font-semibold text-sm text-gray-700 mb-2">Informasi Kunjungan</h4>
                              <div className="space-y-2 text-sm">
                                <div className="flex justify-between">
                                  <span className="text-gray-600">Tanggal:</span>
                                  <span className="font-medium">
                                    {new Date(selectedVisit.date).toLocaleDateString("id-ID")}
                                  </span>
                                </div>
                                <div className="flex justify-between">
                                  <span className="text-gray-600">Waktu:</span>
                                  <span className="font-medium">{selectedVisit.time}</span>
                                </div>
                                <div className="flex justify-between">
                                  <span className="text-gray-600">Dokter:</span>
                                  <span className="font-medium">{selectedVisit.doctor.name}</span>
                                </div>
                                <div className="flex justify-between">
                                  <span className="text-gray-600">Spesialisasi:</span>
                                  <span className="font-medium">{selectedVisit.doctor.specialty}</span>
                                </div>
                                <div className="flex justify-between">
                                  <span className="text-gray-600">Jenis:</span>
                                  <span className="font-medium">{selectedVisit.type}</span>
                                </div>
                              </div>
                            </div>
                            <div>
                              <h4 className="font-semibold text-sm text-gray-700 mb-2">Biaya & Pembayaran</h4>
                              <div className="space-y-2 text-sm">
                                <div className="flex justify-between">
                                  <span className="text-gray-600">Biaya Konsultasi:</span>
                                  <span className="font-medium">Rp {selectedVisit.cost.toLocaleString()}</span>
                                </div>
                                <div className="flex justify-between">
                                  <span className="text-gray-600">Status Pembayaran:</span>
                                  <Badge variant={getPaymentStatusColor(selectedVisit.paymentStatus)}>
                                    {getPaymentStatusText(selectedVisit.paymentStatus)}
                                  </Badge>
                                </div>
                                <div className="flex justify-between">
                                  <span className="text-gray-600">Status Kunjungan:</span>
                                  <Badge variant={getStatusColor(selectedVisit.status)}>
                                    {getStatusText(selectedVisit.status)}
                                  </Badge>
                                </div>
                              </div>
                            </div>
                          </div>

                          {/* Medical Details */}
                          <div className="space-y-4">
                            <div>
                              <h4 className="font-semibold text-sm text-gray-700 mb-2">Diagnosis:</h4>
                              <p className="text-sm bg-blue-50 p-3 rounded-lg">{selectedVisit.diagnosis}</p>
                            </div>
                            <div>
                              <h4 className="font-semibold text-sm text-gray-700 mb-2">Keluhan:</h4>
                              <p className="text-sm bg-gray-50 p-3 rounded-lg">{selectedVisit.symptoms}</p>
                            </div>
                            <div>
                              <h4 className="font-semibold text-sm text-gray-700 mb-2">Pengobatan:</h4>
                              <p className="text-sm bg-green-50 p-3 rounded-lg">{selectedVisit.treatment}</p>
                            </div>
                            <div>
                              <h4 className="font-semibold text-sm text-gray-700 mb-2">Resep:</h4>
                              <p className="text-sm bg-purple-50 p-3 rounded-lg">{selectedVisit.prescription}</p>
                            </div>
                            <div>
                              <h4 className="font-semibold text-sm text-gray-700 mb-2">Catatan Dokter:</h4>
                              <p className="text-sm bg-yellow-50 p-3 rounded-lg">{selectedVisit.notes}</p>
                            </div>
                          </div>

                          {/* Vital Signs */}
                          <div>
                            <h4 className="font-semibold text-sm text-gray-700 mb-3">Tanda Vital:</h4>
                            <div className="grid grid-cols-2 gap-4">
                              {Object.entries(selectedVisit.vitalSigns).map(([key, value]) => (
                                <div key={key} className="flex justify-between p-2 bg-gray-50 rounded">
                                  <span className="text-sm text-gray-600 capitalize">
                                    {key.replace(/([A-Z])/g, " $1").replace(/^./, (str) => str.toUpperCase())}:
                                  </span>
                                  <span className="text-sm font-medium">{value}</span>
                                </div>
                              ))}
                            </div>
                          </div>
                        </div>
                      )}
                    </DialogContent>
                  </Dialog>
                  <Button size="sm" asChild>
                    <Link href={`/patient/medical-records`}>
                      <FileText className="h-4 w-4 mr-2" />
                      Lihat Rekam Medis
                    </Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}

          {history.length === 0 && (
            <Card>
              <CardContent className="text-center py-12">
                <Clock className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Belum Ada Riwayat Kunjungan</h3>
                <p className="text-gray-600 mb-4">
                  Riwayat kunjungan akan muncul setelah Anda melakukan konsultasi dengan dokter.
                </p>
                <Button asChild>
                  <Link href="/patient/appointments">Buat Janji Konsultasi</Link>
                </Button>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}
