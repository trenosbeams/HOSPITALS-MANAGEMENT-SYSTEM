"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Calendar, Clock, User, ArrowLeft, Plus } from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"

export default function PatientAppointments() {
  const [user, setUser] = useState<any>(null)
  const [appointments, setAppointments] = useState<any[]>([])
  const [doctors, setDoctors] = useState<any[]>([])
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false)
  const [newAppointment, setNewAppointment] = useState({
    doctorId: "",
    date: "",
    time: "",
    notes: "",
  })
  const router = useRouter()

  useEffect(() => {
    const userData = localStorage.getItem("user")
    if (userData) {
      const parsedUser = JSON.parse(userData)
      if (parsedUser.role !== "patient") {
        router.push("/login")
      } else {
        setUser(parsedUser)
        loadAppointments()
        loadDoctors()
      }
    } else {
      router.push("/login")
    }
  }, [router])

  const loadAppointments = () => {
    // Mock data - replace with actual API call
    const mockAppointments = [
      {
        id: 1,
        doctor: "Dr. Sarah Johnson",
        specialty: "Kardiologi",
        date: "2024-01-15",
        time: "10:00",
        status: "confirmed",
        notes: "Pemeriksaan rutin jantung",
      },
      {
        id: 2,
        doctor: "Dr. Michael Chen",
        specialty: "Dermatologi",
        date: "2024-01-20",
        time: "14:30",
        status: "pending",
        notes: "Konsultasi masalah kulit",
      },
      {
        id: 3,
        doctor: "Dr. Lisa Wong",
        specialty: "Gizi",
        date: "2024-01-10",
        time: "09:00",
        status: "completed",
        notes: "Konsultasi diet sehat",
      },
    ]
    setAppointments(mockAppointments)
  }

  const loadDoctors = () => {
    // Mock data - replace with actual API call
    const mockDoctors = [
      { id: 1, name: "Dr. Sarah Johnson", specialty: "Kardiologi", fee: 500000 },
      { id: 2, name: "Dr. Michael Chen", specialty: "Dermatologi", fee: 400000 },
      { id: 3, name: "Dr. Lisa Wong", specialty: "Gizi", fee: 350000 },
      { id: 4, name: "Dr. Ahmad Rizki", specialty: "Penyakit Dalam", fee: 450000 },
    ]
    setDoctors(mockDoctors)
  }

  const handleCreateAppointment = () => {
    if (newAppointment.doctorId && newAppointment.date && newAppointment.time) {
      const selectedDoctor = doctors.find((d) => d.id.toString() === newAppointment.doctorId)
      const appointment = {
        id: appointments.length + 1,
        doctor: selectedDoctor?.name,
        specialty: selectedDoctor?.specialty,
        date: newAppointment.date,
        time: newAppointment.time,
        status: "pending",
        notes: newAppointment.notes,
      }

      setAppointments([...appointments, appointment])
      setIsCreateModalOpen(false)
      setNewAppointment({ doctorId: "", date: "", time: "", notes: "" })

      // Show success message
      alert("Janji konsultasi berhasil dibuat! Menunggu konfirmasi dari dokter.")
    }
  }

  const cancelAppointment = (appointmentId: number) => {
    if (confirm("Apakah Anda yakin ingin membatalkan janji konsultasi ini?")) {
      setAppointments(appointments.map((apt) => (apt.id === appointmentId ? { ...apt, status: "cancelled" } : apt)))
      alert("Janji konsultasi berhasil dibatalkan.")
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "confirmed":
        return "default"
      case "pending":
        return "secondary"
      case "completed":
        return "outline"
      case "cancelled":
        return "destructive"
      default:
        return "outline"
    }
  }

  const getStatusText = (status: string) => {
    switch (status) {
      case "confirmed":
        return "Dikonfirmasi"
      case "pending":
        return "Menunggu"
      case "completed":
        return "Selesai"
      case "cancelled":
        return "Dibatalkan"
      default:
        return status
    }
  }

  if (!user) return null

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="sm" asChild>
              <Link href="/patient/dashboard">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Kembali
              </Link>
            </Button>
            <h1 className="text-2xl font-bold text-gray-900">Jadwal Konsultasi</h1>
          </div>
          <Dialog open={isCreateModalOpen} onOpenChange={setIsCreateModalOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Buat Janji Baru
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[425px]">
              <DialogHeader>
                <DialogTitle>Buat Janji Konsultasi</DialogTitle>
                <DialogDescription>Pilih dokter dan jadwal konsultasi yang diinginkan.</DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="doctor">Pilih Dokter</Label>
                  <Select
                    value={newAppointment.doctorId}
                    onValueChange={(value) => setNewAppointment({ ...newAppointment, doctorId: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Pilih dokter" />
                    </SelectTrigger>
                    <SelectContent>
                      {doctors.map((doctor) => (
                        <SelectItem key={doctor.id} value={doctor.id.toString()}>
                          {doctor.name} - {doctor.specialty} (Rp {doctor.fee.toLocaleString()})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="date">Tanggal</Label>
                  <Input
                    id="date"
                    type="date"
                    value={newAppointment.date}
                    onChange={(e) => setNewAppointment({ ...newAppointment, date: e.target.value })}
                    min={new Date().toISOString().split("T")[0]}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="time">Waktu</Label>
                  <Select
                    value={newAppointment.time}
                    onValueChange={(value) => setNewAppointment({ ...newAppointment, time: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Pilih waktu" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="09:00">09:00</SelectItem>
                      <SelectItem value="10:00">10:00</SelectItem>
                      <SelectItem value="11:00">11:00</SelectItem>
                      <SelectItem value="14:00">14:00</SelectItem>
                      <SelectItem value="15:00">15:00</SelectItem>
                      <SelectItem value="16:00">16:00</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="notes">Catatan (Opsional)</Label>
                  <Textarea
                    id="notes"
                    placeholder="Jelaskan keluhan atau tujuan konsultasi"
                    value={newAppointment.notes}
                    onChange={(e) => setNewAppointment({ ...newAppointment, notes: e.target.value })}
                  />
                </div>
              </div>
              <div className="flex justify-end space-x-2">
                <Button variant="outline" onClick={() => setIsCreateModalOpen(false)}>
                  Batal
                </Button>
                <Button onClick={handleCreateAppointment}>Buat Janji</Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Appointments List */}
        <div className="space-y-6">
          {appointments.map((appointment) => (
            <Card key={appointment.id}>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="flex items-center">
                      <User className="h-5 w-5 mr-2" />
                      {appointment.doctor}
                    </CardTitle>
                    <CardDescription>{appointment.specialty}</CardDescription>
                  </div>
                  <Badge variant={getStatusColor(appointment.status)}>{getStatusText(appointment.status)}</Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="flex items-center space-x-2">
                    <Calendar className="h-4 w-4 text-gray-500" />
                    <span>
                      {new Date(appointment.date).toLocaleDateString("id-ID", {
                        weekday: "long",
                        year: "numeric",
                        month: "long",
                        day: "numeric",
                      })}
                    </span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Clock className="h-4 w-4 text-gray-500" />
                    <span>{appointment.time}</span>
                  </div>
                </div>
                {appointment.notes && (
                  <div className="mt-4">
                    <p className="text-sm text-gray-600">
                      <strong>Catatan:</strong> {appointment.notes}
                    </p>
                  </div>
                )}
                <div className="flex justify-end space-x-2 mt-4">
                  {appointment.status === "pending" && (
                    <Button variant="outline" size="sm" onClick={() => cancelAppointment(appointment.id)}>
                      Batalkan
                    </Button>
                  )}
                  {appointment.status === "confirmed" && (
                    <Button size="sm" asChild>
                      <Link href={`/patient/appointments/${appointment.id}/payment`}>Bayar Sekarang</Link>
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}

          {appointments.length === 0 && (
            <Card>
              <CardContent className="text-center py-12">
                <Calendar className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Belum Ada Janji Konsultasi</h3>
                <p className="text-gray-600 mb-4">Buat janji konsultasi pertama Anda dengan dokter pilihan.</p>
                <Button onClick={() => setIsCreateModalOpen(true)}>
                  <Plus className="h-4 w-4 mr-2" />
                  Buat Janji Baru
                </Button>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}
