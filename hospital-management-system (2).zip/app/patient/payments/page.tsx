"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { CreditCard, ArrowLeft, QrCode, Building, CheckCircle, Clock, XCircle } from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"

export default function PatientPayments() {
  const [user, setUser] = useState<any>(null)
  const [payments, setPayments] = useState<any[]>([])
  const [selectedPayment, setSelectedPayment] = useState<any>(null)
  const [paymentMethod, setPaymentMethod] = useState("")
  const router = useRouter()

  useEffect(() => {
    const userData = localStorage.getItem("user")
    if (userData) {
      const parsedUser = JSON.parse(userData)
      if (parsedUser.role !== "patient") {
        router.push("/login")
      } else {
        setUser(parsedUser)
        loadPayments()
      }
    } else {
      router.push("/login")
    }
  }, [router])

  const loadPayments = () => {
    // Mock data - replace with actual API call
    const mockPayments = [
      {
        id: 1,
        appointmentId: 1,
        doctor: "Dr. Sarah Johnson",
        service: "Konsultasi Kardiologi",
        amount: 500000,
        status: "completed",
        paymentMethod: "bank_transfer",
        transactionId: "TXN001",
        date: "2024-01-10",
        dueDate: "2024-01-15",
      },
      {
        id: 2,
        appointmentId: 2,
        doctor: "Dr. Michael Chen",
        service: "Konsultasi Dermatologi",
        amount: 400000,
        status: "pending",
        paymentMethod: null,
        transactionId: null,
        date: null,
        dueDate: "2024-01-20",
      },
      {
        id: 3,
        appointmentId: 3,
        doctor: "Dr. Lisa Wong",
        service: "Konsultasi Gizi",
        amount: 350000,
        status: "failed",
        paymentMethod: "qris",
        transactionId: "TXN002",
        date: "2024-01-05",
        dueDate: "2024-01-10",
      },
    ]
    setPayments(mockPayments)
  }

  const processPayment = (payment: any, method: string) => {
    // Mock payment processing
    const updatedPayments = payments.map((p) =>
      p.id === payment.id
        ? {
            ...p,
            status: "completed",
            paymentMethod: method,
            transactionId: `TXN${Date.now()}`,
            date: new Date().toISOString().split("T")[0],
          }
        : p,
    )
    setPayments(updatedPayments)
    setSelectedPayment(null)
    setPaymentMethod("")
    alert("Pembayaran berhasil diproses!")
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "completed":
        return <CheckCircle className="h-4 w-4 text-green-600" />
      case "pending":
        return <Clock className="h-4 w-4 text-yellow-600" />
      case "failed":
        return <XCircle className="h-4 w-4 text-red-600" />
      default:
        return <Clock className="h-4 w-4 text-gray-600" />
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "default"
      case "pending":
        return "secondary"
      case "failed":
        return "destructive"
      default:
        return "outline"
    }
  }

  const getStatusText = (status: string) => {
    switch (status) {
      case "completed":
        return "Lunas"
      case "pending":
        return "Menunggu Pembayaran"
      case "failed":
        return "Gagal"
      default:
        return status
    }
  }

  const getPaymentMethodText = (method: string) => {
    switch (method) {
      case "bank_transfer":
        return "Transfer Bank"
      case "qris":
        return "QRIS"
      case "cash":
        return "Tunai"
      default:
        return method
    }
  }

  if (!user) return null

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="sm" asChild>
              <Link href="/patient/dashboard">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Kembali
              </Link>
            </Button>
            <h1 className="text-2xl font-bold text-gray-900">Pembayaran</h1>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Payments List */}
        <div className="space-y-6">
          {payments.map((payment) => (
            <Card key={payment.id}>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="flex items-center">
                      <CreditCard className="h-5 w-5 mr-2" />
                      {payment.service}
                    </CardTitle>
                    <CardDescription>{payment.doctor}</CardDescription>
                  </div>
                  <div className="flex items-center space-x-2">
                    {getStatusIcon(payment.status)}
                    <Badge variant={getStatusColor(payment.status)}>{getStatusText(payment.status)}</Badge>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-4 mb-4">
                  <div>
                    <p className="text-sm text-gray-600">Jumlah Tagihan</p>
                    <p className="text-2xl font-bold text-gray-900">Rp {payment.amount.toLocaleString()}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Jatuh Tempo</p>
                    <p className="font-semibold">{new Date(payment.dueDate).toLocaleDateString("id-ID")}</p>
                  </div>
                </div>

                {payment.status === "completed" && (
                  <div className="grid md:grid-cols-2 gap-4 mb-4 p-3 bg-green-50 rounded-lg">
                    <div>
                      <p className="text-sm text-gray-600">Metode Pembayaran</p>
                      <p className="font-semibold">{getPaymentMethodText(payment.paymentMethod)}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">ID Transaksi</p>
                      <p className="font-semibold">{payment.transactionId}</p>
                    </div>
                  </div>
                )}

                <div className="flex justify-end space-x-2">
                  {payment.status === "pending" && (
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button onClick={() => setSelectedPayment(payment)}>Bayar Sekarang</Button>
                      </DialogTrigger>
                      <DialogContent className="sm:max-w-[425px]">
                        <DialogHeader>
                          <DialogTitle>Pilih Metode Pembayaran</DialogTitle>
                          <DialogDescription>
                            Tagihan: Rp {selectedPayment?.amount.toLocaleString()} untuk {selectedPayment?.service}
                          </DialogDescription>
                        </DialogHeader>
                        <div className="space-y-4">
                          <Select value={paymentMethod} onValueChange={setPaymentMethod}>
                            <SelectTrigger>
                              <SelectValue placeholder="Pilih metode pembayaran" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="bank_transfer">
                                <div className="flex items-center">
                                  <Building className="h-4 w-4 mr-2" />
                                  Transfer Bank
                                </div>
                              </SelectItem>
                              <SelectItem value="qris">
                                <div className="flex items-center">
                                  <QrCode className="h-4 w-4 mr-2" />
                                  QRIS
                                </div>
                              </SelectItem>
                            </SelectContent>
                          </Select>

                          {paymentMethod === "bank_transfer" && (
                            <div className="p-4 bg-blue-50 rounded-lg">
                              <h4 className="font-semibold mb-2">Informasi Transfer Bank</h4>
                              <div className="space-y-1 text-sm">
                                <p>
                                  <strong>Bank:</strong> BCA
                                </p>
                                <p>
                                  <strong>No. Rekening:</strong> 1234567890
                                </p>
                                <p>
                                  <strong>Atas Nama:</strong> PT Cipta Hospital Indonesia
                                </p>
                                <p>
                                  <strong>Jumlah:</strong> Rp {selectedPayment?.amount.toLocaleString()}
                                </p>
                              </div>
                            </div>
                          )}

                          {paymentMethod === "qris" && (
                            <div className="p-4 bg-purple-50 rounded-lg text-center">
                              <QrCode className="h-32 w-32 mx-auto mb-2 text-purple-600" />
                              <p className="text-sm">Scan QR Code dengan aplikasi mobile banking atau e-wallet Anda</p>
                            </div>
                          )}

                          <div className="flex justify-end space-x-2">
                            <Button variant="outline" onClick={() => setSelectedPayment(null)}>
                              Batal
                            </Button>
                            <Button
                              onClick={() => processPayment(selectedPayment, paymentMethod)}
                              disabled={!paymentMethod}
                            >
                              Konfirmasi Pembayaran
                            </Button>
                          </div>
                        </div>
                      </DialogContent>
                    </Dialog>
                  )}
                  {payment.status === "failed" && (
                    <Button variant="outline" onClick={() => setSelectedPayment(payment)}>
                      Coba Lagi
                    </Button>
                  )}
                  {payment.status === "completed" && (
                    <Button variant="outline" size="sm">
                      Download Kwitansi
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}

          {payments.length === 0 && (
            <Card>
              <CardContent className="text-center py-12">
                <CreditCard className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Belum Ada Tagihan</h3>
                <p className="text-gray-600 mb-4">
                  Tagihan pembayaran akan muncul setelah Anda membuat janji konsultasi.
                </p>
                <Button asChild>
                  <Link href="/patient/appointments">Buat Janji Konsultasi</Link>
                </Button>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}
