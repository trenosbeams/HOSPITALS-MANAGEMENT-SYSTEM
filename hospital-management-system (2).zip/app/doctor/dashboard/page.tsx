"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Calendar, FileText, Clock, User, LogOut, Bell, Stethoscope, Users } from "lucide-react"
import { useRouter } from "next/navigation"

export default function DoctorDashboard() {
  const [user, setUser] = useState<any>(null)
  const router = useRouter()

  useEffect(() => {
    const userData = localStorage.getItem("user")
    if (userData) {
      const parsedUser = JSON.parse(userData)
      if (parsedUser.role !== "doctor") {
        router.push("/login")
      } else {
        setUser(parsedUser)
      }
    } else {
      router.push("/login")
    }
  }, [router])

  const handleLogout = () => {
    localStorage.removeItem("user")
    router.push("/")
  }

  if (!user) return null

  const todaySchedule = [
    {
      id: 1,
      time: "09:00",
      patient: "John Doe",
      type: "Konsultasi Rutin",
      status: "confirmed",
      duration: "30 menit",
    },
    {
      id: 2,
      time: "10:00",
      patient: "Maria Santos",
      type: "Pemeriksaan Lanjutan",
      status: "in-progress",
      duration: "45 menit",
    },
    {
      id: 3,
      time: "11:30",
      patient: "Ahmad Wijaya",
      type: "Konsultasi Baru",
      status: "pending",
      duration: "30 menit",
    },
    {
      id: 4,
      time: "14:00",
      patient: "Lisa Chen",
      type: "Follow-up",
      status: "confirmed",
      duration: "20 menit",
    },
  ]

  const recentPatients = [
    {
      id: 1,
      name: "John Doe",
      lastVisit: "2024-01-10",
      condition: "Hipertensi",
      status: "stable",
    },
    {
      id: 2,
      name: "Maria Santos",
      lastVisit: "2024-01-08",
      condition: "Diabetes Type 2",
      status: "monitoring",
    },
    {
      id: 3,
      name: "Ahmad Wijaya",
      lastVisit: "2024-01-05",
      condition: "Pemeriksaan Rutin",
      status: "healthy",
    },
  ]

  const stats = [
    {
      title: "Pasien Hari Ini",
      value: "8",
      icon: Users,
      color: "text-blue-600",
    },
    {
      title: "Konsultasi Selesai",
      value: "3",
      icon: Stethoscope,
      color: "text-green-600",
    },
    {
      title: "Jadwal Tersisa",
      value: "5",
      icon: Clock,
      color: "text-orange-600",
    },
    {
      title: "Rekam Medis Baru",
      value: "2",
      icon: FileText,
      color: "text-purple-600",
    },
  ]

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <img src="/images/hospital-logo.png" alt="PERSADA SARI HUSNA Medical Center" className="h-10 w-10" />
            <h1 className="text-2xl font-bold text-gray-900">Dashboard Dokter</h1>
          </div>
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="sm">
              <Bell className="h-4 w-4" />
            </Button>
            <div className="flex items-center space-x-2">
              <User className="h-5 w-5 text-gray-600" />
              <span className="text-sm font-medium">{user.name}</span>
            </div>
            <Button variant="outline" size="sm" onClick={handleLogout}>
              <LogOut className="h-4 w-4 mr-2" />
              Keluar
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-2">Selamat datang, {user.name}!</h2>
          <p className="text-gray-600">Kelola jadwal konsultasi dan rekam medis pasien Anda</p>
        </div>

        {/* Stats Cards */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => (
            <Card key={index}>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">{stat.title}</CardTitle>
                <stat.icon className={`h-4 w-4 ${stat.color}`} />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stat.value}</div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Today's Schedule */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Calendar className="h-5 w-5 mr-2" />
                Jadwal Hari Ini
              </CardTitle>
              <CardDescription>Daftar konsultasi yang dijadwalkan untuk hari ini</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {todaySchedule.map((appointment) => (
                  <div key={appointment.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div>
                      <div className="flex items-center space-x-2">
                        <span className="font-semibold">{appointment.time}</span>
                        <Badge variant="outline">{appointment.duration}</Badge>
                      </div>
                      <p className="text-sm font-medium mt-1">{appointment.patient}</p>
                      <p className="text-sm text-gray-600">{appointment.type}</p>
                    </div>
                    <Badge
                      variant={
                        appointment.status === "confirmed"
                          ? "default"
                          : appointment.status === "in-progress"
                            ? "secondary"
                            : "outline"
                      }
                    >
                      {appointment.status === "confirmed"
                        ? "Dikonfirmasi"
                        : appointment.status === "in-progress"
                          ? "Berlangsung"
                          : "Menunggu"}
                    </Badge>
                  </div>
                ))}
                <Button variant="outline" className="w-full" onClick={() => router.push("/doctor/schedule")}>
                  Lihat Jadwal Lengkap
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Recent Patients */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Users className="h-5 w-5 mr-2" />
                Pasien Terbaru
              </CardTitle>
              <CardDescription>Pasien yang baru saja dikonsultasi</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentPatients.map((patient) => (
                  <div key={patient.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div>
                      <h4 className="font-semibold">{patient.name}</h4>
                      <p className="text-sm text-gray-600">{patient.condition}</p>
                      <p className="text-sm text-gray-500">Kunjungan terakhir: {patient.lastVisit}</p>
                    </div>
                    <Badge
                      variant={
                        patient.status === "healthy" ? "default" : patient.status === "stable" ? "secondary" : "outline"
                      }
                    >
                      {patient.status === "healthy" ? "Sehat" : patient.status === "stable" ? "Stabil" : "Monitoring"}
                    </Badge>
                  </div>
                ))}
                <Button variant="outline" className="w-full" onClick={() => router.push("/doctor/patients")}>
                  Lihat Semua Pasien
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <div className="grid md:grid-cols-3 gap-6 mt-8">
          <Card
            className="hover:shadow-lg transition-shadow cursor-pointer"
            onClick={() => router.push("/doctor/patients")}
          >
            <CardHeader>
              <FileText className="h-8 w-8 text-blue-600 mb-2" />
              <CardTitle>Rekam Medis</CardTitle>
              <CardDescription>Akses dan update rekam medis pasien</CardDescription>
            </CardHeader>
          </Card>

          <Card
            className="hover:shadow-lg transition-shadow cursor-pointer"
            onClick={() => router.push("/doctor/schedule")}
          >
            <CardHeader>
              <Calendar className="h-8 w-8 text-green-600 mb-2" />
              <CardTitle>Atur Jadwal</CardTitle>
              <CardDescription>Kelola jadwal konsultasi dan ketersediaan</CardDescription>
            </CardHeader>
          </Card>

          <Card
            className="hover:shadow-lg transition-shadow cursor-pointer"
            onClick={() => router.push("/doctor/prescriptions")}
          >
            <CardHeader>
              <Stethoscope className="h-8 w-8 text-purple-600 mb-2" />
              <CardTitle>Resep Digital</CardTitle>
              <CardDescription>Buat dan kelola resep obat digital</CardDescription>
            </CardHeader>
          </Card>
        </div>

        {/* Today's Summary */}
        <Card className="mt-8">
          <CardHeader>
            <CardTitle>Ringkasan Hari Ini</CardTitle>
            <CardDescription>Statistik konsultasi dan aktivitas hari ini</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-4 gap-6">
              <div className="text-center p-4 bg-blue-50 rounded-lg">
                <h3 className="text-2xl font-bold text-blue-600">8</h3>
                <p className="text-sm text-gray-600">Total Konsultasi</p>
              </div>
              <div className="text-center p-4 bg-green-50 rounded-lg">
                <h3 className="text-2xl font-bold text-green-600">6 jam</h3>
                <p className="text-sm text-gray-600">Waktu Praktik</p>
              </div>
              <div className="text-center p-4 bg-purple-50 rounded-lg">
                <h3 className="text-2xl font-bold text-purple-600">5</h3>
                <p className="text-sm text-gray-600">Resep Diberikan</p>
              </div>
              <div className="text-center p-4 bg-orange-50 rounded-lg">
                <h3 className="text-2xl font-bold text-orange-600">2</h3>
                <p className="text-sm text-gray-600">Rujukan</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
