"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Users, ArrowLeft, Search, Eye, Plus } from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"

export default function DoctorPatients() {
  const [user, setUser] = useState<any>(null)
  const [patients, setPatients] = useState<any[]>([])
  const [filteredPatients, setFilteredPatients] = useState<any[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedPatient, setSelectedPatient] = useState<any>(null)
  const [newRecord, setNewRecord] = useState({
    diagnosis: "",
    symptoms: "",
    treatment: "",
    prescription: "",
    notes: "",
  })
  const router = useRouter()

  useEffect(() => {
    const userData = localStorage.getItem("user")
    if (userData) {
      const parsedUser = JSON.parse(userData)
      if (parsedUser.role !== "doctor") {
        router.push("/login")
      } else {
        setUser(parsedUser)
        loadPatients()
      }
    } else {
      router.push("/login")
    }
  }, [router])

  useEffect(() => {
    const filtered = patients.filter(
      (patient) =>
        patient.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        patient.condition.toLowerCase().includes(searchTerm.toLowerCase()),
    )
    setFilteredPatients(filtered)
  }, [searchTerm, patients])

  const loadPatients = () => {
    // Mock data - replace with actual API call
    const mockPatients = [
      {
        id: 1,
        name: "John Doe",
        age: 34,
        gender: "Laki-laki",
        phone: "081234567890",
        email: "john.doe@email.com",
        lastVisit: "2024-01-10",
        condition: "Hipertensi",
        status: "stable",
        bloodType: "O+",
        allergies: "Tidak ada",
        emergencyContact: "Jane Doe - 081234567891",
        medicalHistory: [
          {
            date: "2024-01-10",
            diagnosis: "Hipertensi Stadium 1",
            treatment: "Amlodipine 5mg",
            notes: "Kontrol tekanan darah rutin",
          },
          {
            date: "2023-12-15",
            diagnosis: "Pemeriksaan Rutin",
            treatment: "Multivitamin",
            notes: "Kondisi sehat",
          },
        ],
      },
      {
        id: 2,
        name: "Maria Santos",
        age: 28,
        gender: "Perempuan",
        phone: "081234567892",
        email: "maria.santos@email.com",
        lastVisit: "2024-01-08",
        condition: "Diabetes Type 2",
        status: "monitoring",
        bloodType: "A+",
        allergies: "Penisilin",
        emergencyContact: "Carlos Santos - 081234567893",
        medicalHistory: [
          {
            date: "2024-01-08",
            diagnosis: "Diabetes Mellitus Type 2",
            treatment: "Metformin 500mg",
            notes: "Diet rendah gula, olahraga teratur",
          },
        ],
      },
      {
        id: 3,
        name: "Ahmad Wijaya",
        age: 45,
        gender: "Laki-laki",
        phone: "081234567894",
        email: "ahmad.wijaya@email.com",
        lastVisit: "2024-01-05",
        condition: "Pemeriksaan Rutin",
        status: "healthy",
        bloodType: "B+",
        allergies: "Tidak ada",
        emergencyContact: "Siti Wijaya - 081234567895",
        medicalHistory: [
          {
            date: "2024-01-05",
            diagnosis: "Pemeriksaan Rutin",
            treatment: "Tidak ada",
            notes: "Kondisi sehat, lanjutkan gaya hidup sehat",
          },
        ],
      },
    ]
    setPatients(mockPatients)
    setFilteredPatients(mockPatients)
  }

  const addMedicalRecord = (patient: any) => {
    if (newRecord.diagnosis && newRecord.treatment) {
      const record = {
        date: new Date().toISOString().split("T")[0],
        diagnosis: newRecord.diagnosis,
        treatment: newRecord.treatment,
        notes: newRecord.notes,
        symptoms: newRecord.symptoms,
        prescription: newRecord.prescription,
      }

      const updatedPatients = patients.map((p) =>
        p.id === patient.id
          ? {
              ...p,
              medicalHistory: [record, ...p.medicalHistory],
              lastVisit: record.date,
              condition: record.diagnosis,
            }
          : p,
      )

      setPatients(updatedPatients)
      setFilteredPatients(updatedPatients)
      setNewRecord({ diagnosis: "", symptoms: "", treatment: "", prescription: "", notes: "" })
      setSelectedPatient(null)
      alert("Rekam medis berhasil ditambahkan!")
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "healthy":
        return "default"
      case "stable":
        return "secondary"
      case "monitoring":
        return "outline"
      default:
        return "outline"
    }
  }

  const getStatusText = (status: string) => {
    switch (status) {
      case "healthy":
        return "Sehat"
      case "stable":
        return "Stabil"
      case "monitoring":
        return "Monitoring"
      default:
        return status
    }
  }

  if (!user) return null

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="sm" asChild>
              <Link href="/doctor/dashboard">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Kembali
              </Link>
            </Button>
            <h1 className="text-2xl font-bold text-gray-900">Daftar Pasien</h1>
          </div>
          <div className="flex items-center space-x-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="Cari pasien..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 w-64"
              />
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Patients List */}
        <div className="space-y-6">
          {filteredPatients.map((patient) => (
            <Card key={patient.id}>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="flex items-center">
                      <Users className="h-5 w-5 mr-2" />
                      {patient.name}
                    </CardTitle>
                    <CardDescription>
                      {patient.age} tahun • {patient.gender} • {patient.condition}
                    </CardDescription>
                  </div>
                  <Badge variant={getStatusColor(patient.status)}>{getStatusText(patient.status)}</Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-3 gap-4 mb-4">
                  <div>
                    <p className="text-sm text-gray-600">Kontak</p>
                    <p className="font-semibold">{patient.phone}</p>
                    <p className="text-sm text-gray-600">{patient.email}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Kunjungan Terakhir</p>
                    <p className="font-semibold">{new Date(patient.lastVisit).toLocaleDateString("id-ID")}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Golongan Darah</p>
                    <p className="font-semibold">{patient.bloodType}</p>
                  </div>
                </div>

                <div className="flex justify-end space-x-2">
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button variant="outline" size="sm" onClick={() => setSelectedPatient(patient)}>
                        <Eye className="h-4 w-4 mr-2" />
                        Lihat Detail
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="sm:max-w-[700px]">
                      <DialogHeader>
                        <DialogTitle>Detail Pasien - {selectedPatient?.name}</DialogTitle>
                        <DialogDescription>Informasi lengkap dan riwayat medis pasien</DialogDescription>
                      </DialogHeader>
                      {selectedPatient && (
                        <div className="space-y-6">
                          {/* Patient Info */}
                          <div className="grid md:grid-cols-2 gap-4">
                            <div>
                              <h4 className="font-semibold text-sm text-gray-700 mb-2">Informasi Pribadi</h4>
                              <div className="space-y-1 text-sm">
                                <p>
                                  <strong>Nama:</strong> {selectedPatient.name}
                                </p>
                                <p>
                                  <strong>Umur:</strong> {selectedPatient.age} tahun
                                </p>
                                <p>
                                  <strong>Jenis Kelamin:</strong> {selectedPatient.gender}
                                </p>
                                <p>
                                  <strong>Golongan Darah:</strong> {selectedPatient.bloodType}
                                </p>
                                <p>
                                  <strong>Alergi:</strong> {selectedPatient.allergies}
                                </p>
                              </div>
                            </div>
                            <div>
                              <h4 className="font-semibold text-sm text-gray-700 mb-2">Kontak</h4>
                              <div className="space-y-1 text-sm">
                                <p>
                                  <strong>Telepon:</strong> {selectedPatient.phone}
                                </p>
                                <p>
                                  <strong>Email:</strong> {selectedPatient.email}
                                </p>
                                <p>
                                  <strong>Kontak Darurat:</strong> {selectedPatient.emergencyContact}
                                </p>
                              </div>
                            </div>
                          </div>

                          {/* Medical History */}
                          <div>
                            <h4 className="font-semibold text-sm text-gray-700 mb-2">Riwayat Medis</h4>
                            <div className="space-y-3 max-h-60 overflow-y-auto">
                              {selectedPatient.medicalHistory.map((record: any, index: number) => (
                                <div key={index} className="p-3 border rounded-lg">
                                  <div className="flex justify-between items-start mb-2">
                                    <h5 className="font-semibold">{record.diagnosis}</h5>
                                    <span className="text-sm text-gray-500">
                                      {new Date(record.date).toLocaleDateString("id-ID")}
                                    </span>
                                  </div>
                                  <p className="text-sm text-gray-600 mb-1">
                                    <strong>Pengobatan:</strong> {record.treatment}
                                  </p>
                                  {record.notes && (
                                    <p className="text-sm text-gray-600">
                                      <strong>Catatan:</strong> {record.notes}
                                    </p>
                                  )}
                                </div>
                              ))}
                            </div>
                          </div>
                        </div>
                      )}
                    </DialogContent>
                  </Dialog>

                  <Dialog>
                    <DialogTrigger asChild>
                      <Button size="sm" onClick={() => setSelectedPatient(patient)}>
                        <Plus className="h-4 w-4 mr-2" />
                        Tambah Rekam Medis
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="sm:max-w-[500px]">
                      <DialogHeader>
                        <DialogTitle>Tambah Rekam Medis</DialogTitle>
                        <DialogDescription>
                          Tambahkan catatan medis baru untuk {selectedPatient?.name}
                        </DialogDescription>
                      </DialogHeader>
                      <div className="space-y-4">
                        <div className="space-y-2">
                          <Label htmlFor="diagnosis">Diagnosis *</Label>
                          <Input
                            id="diagnosis"
                            placeholder="Masukkan diagnosis"
                            value={newRecord.diagnosis}
                            onChange={(e) => setNewRecord({ ...newRecord, diagnosis: e.target.value })}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="symptoms">Keluhan/Gejala</Label>
                          <Textarea
                            id="symptoms"
                            placeholder="Jelaskan keluhan atau gejala pasien"
                            value={newRecord.symptoms}
                            onChange={(e) => setNewRecord({ ...newRecord, symptoms: e.target.value })}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="treatment">Pengobatan *</Label>
                          <Textarea
                            id="treatment"
                            placeholder="Rencana pengobatan atau tindakan"
                            value={newRecord.treatment}
                            onChange={(e) => setNewRecord({ ...newRecord, treatment: e.target.value })}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="prescription">Resep Obat</Label>
                          <Textarea
                            id="prescription"
                            placeholder="Daftar obat yang diresepkan"
                            value={newRecord.prescription}
                            onChange={(e) => setNewRecord({ ...newRecord, prescription: e.target.value })}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="notes">Catatan Tambahan</Label>
                          <Textarea
                            id="notes"
                            placeholder="Catatan atau instruksi khusus"
                            value={newRecord.notes}
                            onChange={(e) => setNewRecord({ ...newRecord, notes: e.target.value })}
                          />
                        </div>
                        <div className="flex justify-end space-x-2">
                          <Button variant="outline" onClick={() => setSelectedPatient(null)}>
                            Batal
                          </Button>
                          <Button onClick={() => addMedicalRecord(selectedPatient)}>Simpan Rekam Medis</Button>
                        </div>
                      </div>
                    </DialogContent>
                  </Dialog>
                </div>
              </CardContent>
            </Card>
          ))}

          {filteredPatients.length === 0 && (
            <Card>
              <CardContent className="text-center py-12">
                <Users className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">
                  {searchTerm ? "Pasien Tidak Ditemukan" : "Belum Ada Pasien"}
                </h3>
                <p className="text-gray-600">
                  {searchTerm
                    ? "Coba gunakan kata kunci pencarian yang berbeda."
                    : "Pasien akan muncul setelah membuat janji konsultasi."}
                </p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}
