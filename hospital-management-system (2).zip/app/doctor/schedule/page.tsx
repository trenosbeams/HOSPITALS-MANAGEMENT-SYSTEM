"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Calendar, ArrowLeft, Clock, User, Plus, ChevronLeft, ChevronRight } from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"

export default function DoctorSchedule() {
  const [user, setUser] = useState<any>(null)
  const [currentDate, setCurrentDate] = useState(new Date())
  const [selectedDate, setSelectedDate] = useState(new Date())
  const [schedule, setSchedule] = useState<any[]>([])
  const [isAddModalOpen, setIsAddModalOpen] = useState(false)
  const [isEditModalOpen, setIsEditModalOpen] = useState(false)
  const [selectedAppointment, setSelectedAppointment] = useState<any>(null)
  const [newSchedule, setNewSchedule] = useState({
    date: "",
    time: "",
    duration: "30",
    type: "available",
    notes: "",
  })
  const router = useRouter()

  useEffect(() => {
    const userData = localStorage.getItem("user")
    if (userData) {
      const parsedUser = JSON.parse(userData)
      if (parsedUser.role !== "doctor") {
        router.push("/login")
      } else {
        setUser(parsedUser)
        loadSchedule()
      }
    } else {
      router.push("/login")
    }
  }, [router])

  const loadSchedule = () => {
    // Mock data - replace with actual API call
    const mockSchedule = [
      {
        id: 1,
        date: "2024-01-15",
        time: "09:00",
        duration: 30,
        type: "appointment",
        status: "confirmed",
        patient: {
          id: 1,
          name: "John Doe",
          age: 34,
          phone: "081234567890",
          email: "john.doe@email.com",
          condition: "Hipertensi",
          lastVisit: "2024-01-10",
        },
        notes: "Konsultasi rutin hipertensi",
      },
      {
        id: 2,
        date: "2024-01-15",
        time: "10:00",
        duration: 45,
        type: "appointment",
        status: "pending",
        patient: {
          id: 2,
          name: "Maria Santos",
          age: 28,
          phone: "081234567892",
          email: "maria.santos@email.com",
          condition: "Diabetes Type 2",
          lastVisit: "2024-01-08",
        },
        notes: "Pemeriksaan lanjutan diabetes",
      },
      {
        id: 3,
        date: "2024-01-15",
        time: "11:30",
        duration: 30,
        type: "appointment",
        status: "confirmed",
        patient: {
          id: 3,
          name: "Ahmad Wijaya",
          age: 45,
          phone: "081234567894",
          email: "ahmad.wijaya@email.com",
          condition: "Pemeriksaan Rutin",
          lastVisit: "2024-01-05",
        },
        notes: "Konsultasi baru",
      },
      {
        id: 4,
        date: "2024-01-15",
        time: "14:00",
        duration: 30,
        type: "available",
        status: "available",
        patient: null,
        notes: "Slot tersedia",
      },
      {
        id: 5,
        date: "2024-01-15",
        time: "15:00",
        duration: 30,
        type: "break",
        status: "break",
        patient: null,
        notes: "Istirahat",
      },
      {
        id: 6,
        date: "2024-01-16",
        time: "09:00",
        duration: 30,
        type: "appointment",
        status: "confirmed",
        patient: {
          id: 4,
          name: "Lisa Chen",
          age: 31,
          phone: "081234567896",
          email: "lisa.chen@email.com",
          condition: "Dermatitis",
          lastVisit: "2023-12-20",
        },
        notes: "Follow-up dermatitis",
      },
      {
        id: 7,
        date: "2024-01-16",
        time: "10:30",
        duration: 60,
        type: "appointment",
        status: "confirmed",
        patient: {
          id: 5,
          name: "Robert Kim",
          age: 52,
          phone: "081234567898",
          email: "robert.kim@email.com",
          condition: "Pemeriksaan Jantung",
          lastVisit: "2024-01-12",
        },
        notes: "Pemeriksaan jantung komprehensif",
      },
    ]
    setSchedule(mockSchedule)
  }

  const getDaysInMonth = (date: Date) => {
    const year = date.getFullYear()
    const month = date.getMonth()
    const firstDay = new Date(year, month, 1)
    const lastDay = new Date(year, month + 1, 0)
    const daysInMonth = lastDay.getDate()
    const startingDayOfWeek = firstDay.getDay()

    const days = []

    // Add empty cells for days before the first day of the month
    for (let i = 0; i < startingDayOfWeek; i++) {
      days.push(null)
    }

    // Add days of the month
    for (let day = 1; day <= daysInMonth; day++) {
      days.push(new Date(year, month, day))
    }

    return days
  }

  const getScheduleForDate = (date: Date) => {
    const dateString = date.toISOString().split("T")[0]
    return schedule.filter((item) => item.date === dateString)
  }

  const addScheduleSlot = () => {
    if (newSchedule.date && newSchedule.time) {
      const newSlot = {
        id: schedule.length + 1,
        date: newSchedule.date,
        time: newSchedule.time,
        duration: Number.parseInt(newSchedule.duration),
        type: newSchedule.type,
        status: newSchedule.type === "available" ? "available" : newSchedule.type,
        patient: null,
        notes: newSchedule.notes,
      }

      setSchedule([...schedule, newSlot])
      setIsAddModalOpen(false)
      setNewSchedule({ date: "", time: "", duration: "30", type: "available", notes: "" })
      alert("Jadwal berhasil ditambahkan!")
    }
  }

  const updateAppointmentStatus = (appointmentId: number, newStatus: string) => {
    const updatedSchedule = schedule.map((item) => (item.id === appointmentId ? { ...item, status: newStatus } : item))
    setSchedule(updatedSchedule)
    alert(`Status janji berhasil diubah menjadi ${newStatus}`)
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "confirmed":
        return "default"
      case "pending":
        return "secondary"
      case "completed":
        return "outline"
      case "cancelled":
        return "destructive"
      case "available":
        return "outline"
      case "break":
        return "secondary"
      default:
        return "outline"
    }
  }

  const getStatusText = (status: string) => {
    switch (status) {
      case "confirmed":
        return "Dikonfirmasi"
      case "pending":
        return "Menunggu"
      case "completed":
        return "Selesai"
      case "cancelled":
        return "Dibatalkan"
      case "available":
        return "Tersedia"
      case "break":
        return "Istirahat"
      default:
        return status
    }
  }

  const navigateMonth = (direction: "prev" | "next") => {
    const newDate = new Date(currentDate)
    if (direction === "prev") {
      newDate.setMonth(newDate.getMonth() - 1)
    } else {
      newDate.setMonth(newDate.getMonth() + 1)
    }
    setCurrentDate(newDate)
  }

  const isToday = (date: Date) => {
    const today = new Date()
    return date.toDateString() === today.toDateString()
  }

  const isSelected = (date: Date) => {
    return date.toDateString() === selectedDate.toDateString()
  }

  const hasAppointments = (date: Date) => {
    const dateString = date.toISOString().split("T")[0]
    return schedule.some((item) => item.date === dateString && item.type === "appointment")
  }

  if (!user) return null

  const days = getDaysInMonth(currentDate)
  const selectedDateSchedule = getScheduleForDate(selectedDate)

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="sm" asChild>
              <Link href="/doctor/dashboard">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Kembali
              </Link>
            </Button>
            <h1 className="text-2xl font-bold text-gray-900">Jadwal Praktik</h1>
          </div>
          <Dialog open={isAddModalOpen} onOpenChange={setIsAddModalOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Tambah Jadwal
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[425px]">
              <DialogHeader>
                <DialogTitle>Tambah Jadwal Baru</DialogTitle>
                <DialogDescription>Buat slot waktu baru untuk praktik Anda.</DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="date">Tanggal</Label>
                  <Input
                    id="date"
                    type="date"
                    value={newSchedule.date}
                    onChange={(e) => setNewSchedule({ ...newSchedule, date: e.target.value })}
                    min={new Date().toISOString().split("T")[0]}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="time">Waktu</Label>
                  <Input
                    id="time"
                    type="time"
                    value={newSchedule.time}
                    onChange={(e) => setNewSchedule({ ...newSchedule, time: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="duration">Durasi (menit)</Label>
                  <Select
                    value={newSchedule.duration}
                    onValueChange={(value) => setNewSchedule({ ...newSchedule, duration: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="15">15 menit</SelectItem>
                      <SelectItem value="30">30 menit</SelectItem>
                      <SelectItem value="45">45 menit</SelectItem>
                      <SelectItem value="60">60 menit</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="type">Jenis</Label>
                  <Select
                    value={newSchedule.type}
                    onValueChange={(value) => setNewSchedule({ ...newSchedule, type: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="available">Slot Tersedia</SelectItem>
                      <SelectItem value="break">Istirahat</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="notes">Catatan (Opsional)</Label>
                  <Input
                    id="notes"
                    placeholder="Catatan tambahan"
                    value={newSchedule.notes}
                    onChange={(e) => setNewSchedule({ ...newSchedule, notes: e.target.value })}
                  />
                </div>
              </div>
              <div className="flex justify-end space-x-2">
                <Button variant="outline" onClick={() => setIsAddModalOpen(false)}>
                  Batal
                </Button>
                <Button onClick={addScheduleSlot}>Tambah Jadwal</Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Calendar */}
          <Card className="lg:col-span-1">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center">
                  <Calendar className="h-5 w-5 mr-2" />
                  {currentDate.toLocaleDateString("id-ID", { month: "long", year: "numeric" })}
                </CardTitle>
                <div className="flex space-x-1">
                  <Button variant="outline" size="sm" onClick={() => navigateMonth("prev")}>
                    <ChevronLeft className="h-4 w-4" />
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => navigateMonth("next")}>
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-7 gap-1 mb-4">
                {["Min", "Sen", "Sel", "Rab", "Kam", "Jum", "Sab"].map((day) => (
                  <div key={day} className="text-center text-sm font-medium text-gray-500 p-2">
                    {day}
                  </div>
                ))}
              </div>
              <div className="grid grid-cols-7 gap-1">
                {days.map((day, index) => (
                  <div key={index} className="aspect-square">
                    {day && (
                      <button
                        onClick={() => setSelectedDate(day)}
                        className={`w-full h-full flex items-center justify-center text-sm rounded-lg transition-colors relative ${
                          isSelected(day)
                            ? "bg-blue-600 text-white"
                            : isToday(day)
                              ? "bg-blue-100 text-blue-600 font-semibold"
                              : "hover:bg-gray-100"
                        }`}
                      >
                        {day.getDate()}
                        {hasAppointments(day) && (
                          <div className="absolute bottom-1 left-1/2 transform -translate-x-1/2 w-1 h-1 bg-red-500 rounded-full"></div>
                        )}
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Schedule for Selected Date */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle>
                Jadwal{" "}
                {selectedDate.toLocaleDateString("id-ID", {
                  weekday: "long",
                  year: "numeric",
                  month: "long",
                  day: "numeric",
                })}
              </CardTitle>
              <CardDescription>{selectedDateSchedule.length} jadwal untuk hari ini</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {selectedDateSchedule.length > 0 ? (
                  selectedDateSchedule
                    .sort((a, b) => a.time.localeCompare(b.time))
                    .map((appointment) => (
                      <div key={appointment.id} className="flex items-center justify-between p-4 border rounded-lg">
                        <div className="flex-1">
                          <div className="flex items-center space-x-2 mb-2">
                            <Clock className="h-4 w-4 text-gray-500" />
                            <span className="font-semibold">{appointment.time}</span>
                            <Badge variant="outline">{appointment.duration} menit</Badge>
                            <Badge variant={getStatusColor(appointment.status)}>
                              {getStatusText(appointment.status)}
                            </Badge>
                          </div>

                          {appointment.patient ? (
                            <Dialog>
                              <DialogTrigger asChild>
                                <div className="cursor-pointer hover:bg-gray-50 p-2 rounded transition-colors">
                                  <div className="flex items-center space-x-2">
                                    <User className="h-4 w-4 text-blue-600" />
                                    <span className="font-medium text-blue-600 hover:underline">
                                      {appointment.patient.name}
                                    </span>
                                  </div>
                                  <p className="text-sm text-gray-600 ml-6">{appointment.notes}</p>
                                </div>
                              </DialogTrigger>
                              <DialogContent className="sm:max-w-[600px]">
                                <DialogHeader>
                                  <DialogTitle>Detail Pasien - {appointment.patient.name}</DialogTitle>
                                  <DialogDescription>
                                    Informasi lengkap pasien untuk konsultasi {appointment.time}
                                  </DialogDescription>
                                </DialogHeader>
                                <div className="space-y-6">
                                  {/* Patient Basic Info */}
                                  <div className="grid md:grid-cols-2 gap-4">
                                    <div>
                                      <h4 className="font-semibold text-sm text-gray-700 mb-2">Informasi Pribadi</h4>
                                      <div className="space-y-2 text-sm">
                                        <div className="flex justify-between">
                                          <span className="text-gray-600">Nama:</span>
                                          <span className="font-medium">{appointment.patient.name}</span>
                                        </div>
                                        <div className="flex justify-between">
                                          <span className="text-gray-600">Umur:</span>
                                          <span className="font-medium">{appointment.patient.age} tahun</span>
                                        </div>
                                        <div className="flex justify-between">
                                          <span className="text-gray-600">Telepon:</span>
                                          <span className="font-medium">{appointment.patient.phone}</span>
                                        </div>
                                        <div className="flex justify-between">
                                          <span className="text-gray-600">Email:</span>
                                          <span className="font-medium">{appointment.patient.email}</span>
                                        </div>
                                      </div>
                                    </div>
                                    <div>
                                      <h4 className="font-semibold text-sm text-gray-700 mb-2">Informasi Medis</h4>
                                      <div className="space-y-2 text-sm">
                                        <div className="flex justify-between">
                                          <span className="text-gray-600">Kondisi:</span>
                                          <span className="font-medium">{appointment.patient.condition}</span>
                                        </div>
                                        <div className="flex justify-between">
                                          <span className="text-gray-600">Kunjungan Terakhir:</span>
                                          <span className="font-medium">
                                            {new Date(appointment.patient.lastVisit).toLocaleDateString("id-ID")}
                                          </span>
                                        </div>
                                      </div>
                                    </div>
                                  </div>

                                  {/* Appointment Details */}
                                  <div className="border-t pt-4">
                                    <h4 className="font-semibold text-sm text-gray-700 mb-2">Detail Konsultasi</h4>
                                    <div className="bg-blue-50 p-4 rounded-lg">
                                      <div className="grid md:grid-cols-2 gap-4 text-sm">
                                        <div className="flex justify-between">
                                          <span className="text-gray-600">Tanggal:</span>
                                          <span className="font-medium">
                                            {new Date(appointment.date).toLocaleDateString("id-ID")}
                                          </span>
                                        </div>
                                        <div className="flex justify-between">
                                          <span className="text-gray-600">Waktu:</span>
                                          <span className="font-medium">{appointment.time}</span>
                                        </div>
                                        <div className="flex justify-between">
                                          <span className="text-gray-600">Durasi:</span>
                                          <span className="font-medium">{appointment.duration} menit</span>
                                        </div>
                                        <div className="flex justify-between">
                                          <span className="text-gray-600">Status:</span>
                                          <Badge variant={getStatusColor(appointment.status)}>
                                            {getStatusText(appointment.status)}
                                          </Badge>
                                        </div>
                                      </div>
                                      {appointment.notes && (
                                        <div className="mt-3 pt-3 border-t border-blue-200">
                                          <span className="text-gray-600 text-sm">Catatan:</span>
                                          <p className="text-sm mt-1">{appointment.notes}</p>
                                        </div>
                                      )}
                                    </div>
                                  </div>

                                  {/* Quick Actions */}
                                  <div className="border-t pt-4">
                                    <h4 className="font-semibold text-sm text-gray-700 mb-3">Aksi Cepat</h4>
                                    <div className="flex flex-wrap gap-2">
                                      <Button
                                        size="sm"
                                        onClick={() => router.push(`/doctor/patients/${appointment.patient.id}`)}
                                      >
                                        Lihat Rekam Medis
                                      </Button>
                                      {appointment.status === "pending" && (
                                        <Button
                                          size="sm"
                                          variant="outline"
                                          onClick={() => updateAppointmentStatus(appointment.id, "confirmed")}
                                        >
                                          Konfirmasi Janji
                                        </Button>
                                      )}
                                      {appointment.status === "confirmed" && (
                                        <Button
                                          size="sm"
                                          variant="outline"
                                          onClick={() => updateAppointmentStatus(appointment.id, "completed")}
                                        >
                                          Selesai Konsultasi
                                        </Button>
                                      )}
                                      <Button
                                        size="sm"
                                        variant="outline"
                                        onClick={() => window.open(`tel:${appointment.patient.phone}`)}
                                      >
                                        Hubungi Pasien
                                      </Button>
                                    </div>
                                  </div>
                                </div>
                              </DialogContent>
                            </Dialog>
                          ) : (
                            <div className="ml-6">
                              <p className="text-sm text-gray-600">{appointment.notes}</p>
                            </div>
                          )}
                        </div>

                        <div className="flex space-x-2">
                          {appointment.type === "appointment" && appointment.status === "pending" && (
                            <>
                              <Button size="sm" onClick={() => updateAppointmentStatus(appointment.id, "confirmed")}>
                                Konfirmasi
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => updateAppointmentStatus(appointment.id, "cancelled")}
                              >
                                Batalkan
                              </Button>
                            </>
                          )}
                          {appointment.type === "appointment" && appointment.status === "confirmed" && (
                            <Button size="sm" onClick={() => updateAppointmentStatus(appointment.id, "completed")}>
                              Selesai
                            </Button>
                          )}
                        </div>
                      </div>
                    ))
                ) : (
                  <div className="text-center py-12">
                    <Calendar className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">Tidak Ada Jadwal</h3>
                    <p className="text-gray-600 mb-4">Belum ada jadwal untuk tanggal yang dipilih.</p>
                    <Button onClick={() => setIsAddModalOpen(true)}>
                      <Plus className="h-4 w-4 mr-2" />
                      Tambah Jadwal
                    </Button>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Weekly Overview */}
        <Card className="mt-8">
          <CardHeader>
            <CardTitle>Ringkasan Minggu Ini</CardTitle>
            <CardDescription>Statistik jadwal dan konsultasi minggu ini</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-4 gap-6">
              <div className="text-center p-4 bg-blue-50 rounded-lg">
                <h3 className="text-2xl font-bold text-blue-600">
                  {schedule.filter((s) => s.type === "appointment").length}
                </h3>
                <p className="text-sm text-gray-600">Total Konsultasi</p>
              </div>
              <div className="text-center p-4 bg-green-50 rounded-lg">
                <h3 className="text-2xl font-bold text-green-600">
                  {schedule.filter((s) => s.status === "completed").length}
                </h3>
                <p className="text-sm text-gray-600">Selesai</p>
              </div>
              <div className="text-center p-4 bg-yellow-50 rounded-lg">
                <h3 className="text-2xl font-bold text-yellow-600">
                  {schedule.filter((s) => s.status === "pending").length}
                </h3>
                <p className="text-sm text-gray-600">Menunggu</p>
              </div>
              <div className="text-center p-4 bg-purple-50 rounded-lg">
                <h3 className="text-2xl font-bold text-purple-600">
                  {schedule.filter((s) => s.status === "available").length}
                </h3>
                <p className="text-sm text-gray-600">Slot Tersedia</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
