"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Stethoscope, ArrowLeft, Search, Plus, Eye, Download, Pill } from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"

export default function DoctorPrescriptions() {
  const [user, setUser] = useState<any>(null)
  const [prescriptions, setPrescriptions] = useState<any[]>([])
  const [filteredPrescriptions, setFilteredPrescriptions] = useState<any[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false)
  const [selectedPrescription, setSelectedPrescription] = useState<any>(null)
  const [newPrescription, setNewPrescription] = useState({
    patientId: "",
    patientName: "",
    diagnosis: "",
    medications: [{ name: "", dosage: "", frequency: "", duration: "", instructions: "" }],
    notes: "",
  })
  const router = useRouter()

  useEffect(() => {
    const userData = localStorage.getItem("user")
    if (userData) {
      const parsedUser = JSON.parse(userData)
      if (parsedUser.role !== "doctor") {
        router.push("/login")
      } else {
        setUser(parsedUser)
        loadPrescriptions()
      }
    } else {
      router.push("/login")
    }
  }, [router])

  useEffect(() => {
    const filtered = prescriptions.filter(
      (prescription) =>
        prescription.patient.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        prescription.diagnosis.toLowerCase().includes(searchTerm.toLowerCase()) ||
        prescription.medications.some((med: any) => med.name.toLowerCase().includes(searchTerm.toLowerCase())),
    )
    setFilteredPrescriptions(filtered)
  }, [searchTerm, prescriptions])

  const loadPrescriptions = () => {
    // Mock data - replace with actual API call
    const mockPrescriptions = [
      {
        id: 1,
        date: "2024-01-15",
        patient: {
          id: 1,
          name: "John Doe",
          age: 34,
          phone: "081234567890",
          email: "john.doe@email.com",
        },
        diagnosis: "Hipertensi Stadium 1",
        medications: [
          {
            name: "Amlodipine",
            dosage: "5mg",
            frequency: "1x sehari",
            duration: "30 hari",
            instructions: "Diminum setelah makan pagi",
          },
          {
            name: "Lisinopril",
            dosage: "10mg",
            frequency: "1x sehari",
            duration: "30 hari",
            instructions: "Diminum bersamaan dengan Amlodipine",
          },
        ],
        notes: "Kontrol tekanan darah setiap 2 minggu. Hindari makanan tinggi garam.",
        status: "active",
        createdAt: "2024-01-15T10:00:00Z",
      },
      {
        id: 2,
        date: "2024-01-12",
        patient: {
          id: 2,
          name: "Maria Santos",
          age: 28,
          phone: "081234567892",
          email: "maria.santos@email.com",
        },
        diagnosis: "Diabetes Mellitus Type 2",
        medications: [
          {
            name: "Metformin",
            dosage: "500mg",
            frequency: "2x sehari",
            duration: "90 hari",
            instructions: "Diminum setelah makan pagi dan malam",
          },
          {
            name: "Glimepiride",
            dosage: "2mg",
            frequency: "1x sehari",
            duration: "90 hari",
            instructions: "Diminum 30 menit sebelum makan pagi",
          },
        ],
        notes: "Diet rendah gula dan karbohidrat. Olahraga teratur 3x seminggu.",
        status: "active",
        createdAt: "2024-01-12T14:30:00Z",
      },
      {
        id: 3,
        date: "2024-01-08",
        patient: {
          id: 3,
          name: "Ahmad Wijaya",
          age: 45,
          phone: "081234567894",
          email: "ahmad.wijaya@email.com",
        },
        diagnosis: "Gastritis Akut",
        medications: [
          {
            name: "Omeprazole",
            dosage: "20mg",
            frequency: "1x sehari",
            duration: "14 hari",
            instructions: "Diminum 30 menit sebelum makan pagi",
          },
          {
            name: "Sucralfate",
            dosage: "1g",
            frequency: "3x sehari",
            duration: "14 hari",
            instructions: "Diminum 1 jam sebelum makan",
          },
        ],
        notes: "Hindari makanan pedas, asam, dan berlemak. Makan teratur.",
        status: "completed",
        createdAt: "2024-01-08T09:15:00Z",
      },
    ]
    setPrescriptions(mockPrescriptions)
    setFilteredPrescriptions(mockPrescriptions)
  }

  const addMedication = () => {
    setNewPrescription({
      ...newPrescription,
      medications: [
        ...newPrescription.medications,
        { name: "", dosage: "", frequency: "", duration: "", instructions: "" },
      ],
    })
  }

  const removeMedication = (index: number) => {
    const updatedMedications = newPrescription.medications.filter((_, i) => i !== index)
    setNewPrescription({ ...newPrescription, medications: updatedMedications })
  }

  const updateMedication = (index: number, field: string, value: string) => {
    const updatedMedications = newPrescription.medications.map((med, i) =>
      i === index ? { ...med, [field]: value } : med,
    )
    setNewPrescription({ ...newPrescription, medications: updatedMedications })
  }

  const createPrescription = () => {
    if (newPrescription.patientName && newPrescription.diagnosis && newPrescription.medications[0].name) {
      const prescription = {
        id: prescriptions.length + 1,
        date: new Date().toISOString().split("T")[0],
        patient: {
          id: prescriptions.length + 1,
          name: newPrescription.patientName,
          age: 0,
          phone: "",
          email: "",
        },
        diagnosis: newPrescription.diagnosis,
        medications: newPrescription.medications.filter((med) => med.name),
        notes: newPrescription.notes,
        status: "active",
        createdAt: new Date().toISOString(),
      }

      setPrescriptions([prescription, ...prescriptions])
      setFilteredPrescriptions([prescription, ...prescriptions])
      setIsCreateModalOpen(false)
      setNewPrescription({
        patientId: "",
        patientName: "",
        diagnosis: "",
        medications: [{ name: "", dosage: "", frequency: "", duration: "", instructions: "" }],
        notes: "",
      })
      alert("Resep digital berhasil dibuat!")
    }
  }

  const downloadPrescription = (prescription: any) => {
    const content = `
RESEP DIGITAL
PT Cipta Hospital Indonesia

Tanggal: ${prescription.date}
Dokter: ${user.name}

PASIEN:
Nama: ${prescription.patient.name}
Umur: ${prescription.patient.age} tahun

DIAGNOSIS: ${prescription.diagnosis}

RESEP OBAT:
${prescription.medications
  .map(
    (med: any, index: number) => `
${index + 1}. ${med.name} ${med.dosage}
   Aturan pakai: ${med.frequency}
   Durasi: ${med.duration}
   Petunjuk: ${med.instructions}`,
  )
  .join("\n")}

CATATAN DOKTER:
${prescription.notes}

Resep ini berlaku selama 30 hari dari tanggal penerbitan.
    `

    const blob = new Blob([content], { type: "text/plain" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `resep-${prescription.patient.name}-${prescription.date}.txt`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  const getStatusColor = (status: string) => {
    return status === "active" ? "default" : "outline"
  }

  const getStatusText = (status: string) => {
    return status === "active" ? "Aktif" : "Selesai"
  }

  if (!user) return null

  // Mock patient list for dropdown
  const availablePatients = [
    { id: 1, name: "John Doe" },
    { id: 2, name: "Maria Santos" },
    { id: 3, name: "Ahmad Wijaya" },
    { id: 4, name: "Lisa Chen" },
    { id: 5, name: "Robert Kim" },
  ]

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="sm" asChild>
              <Link href="/doctor/dashboard">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Kembali
              </Link>
            </Button>
            <h1 className="text-2xl font-bold text-gray-900">Resep Digital</h1>
          </div>
          <div className="flex items-center space-x-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="Cari resep atau pasien..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 w-64"
              />
            </div>
            <Dialog open={isCreateModalOpen} onOpenChange={setIsCreateModalOpen}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  Buat Resep Baru
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[700px] max-h-[80vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>Buat Resep Digital Baru</DialogTitle>
                  <DialogDescription>Buat resep obat digital untuk pasien.</DialogDescription>
                </DialogHeader>
                <div className="space-y-6">
                  {/* Patient Selection */}
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="patient">Pilih Pasien</Label>
                      <Select
                        value={newPrescription.patientName}
                        onValueChange={(value) => setNewPrescription({ ...newPrescription, patientName: value })}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Pilih pasien" />
                        </SelectTrigger>
                        <SelectContent>
                          {availablePatients.map((patient) => (
                            <SelectItem key={patient.id} value={patient.name}>
                              {patient.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="diagnosis">Diagnosis</Label>
                      <Input
                        id="diagnosis"
                        placeholder="Masukkan diagnosis"
                        value={newPrescription.diagnosis}
                        onChange={(e) => setNewPrescription({ ...newPrescription, diagnosis: e.target.value })}
                      />
                    </div>
                  </div>

                  {/* Medications */}
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <Label className="text-base font-semibold">Daftar Obat</Label>
                      <Button type="button" variant="outline" size="sm" onClick={addMedication}>
                        <Plus className="h-4 w-4 mr-2" />
                        Tambah Obat
                      </Button>
                    </div>

                    {newPrescription.medications.map((medication, index) => (
                      <Card key={index} className="p-4">
                        <div className="space-y-4">
                          <div className="flex items-center justify-between">
                            <h4 className="font-medium">Obat {index + 1}</h4>
                            {newPrescription.medications.length > 1 && (
                              <Button type="button" variant="outline" size="sm" onClick={() => removeMedication(index)}>
                                Hapus
                              </Button>
                            )}
                          </div>
                          <div className="grid md:grid-cols-2 gap-4">
                            <div className="space-y-2">
                              <Label>Nama Obat</Label>
                              <Input
                                placeholder="Nama obat"
                                value={medication.name}
                                onChange={(e) => updateMedication(index, "name", e.target.value)}
                              />
                            </div>
                            <div className="space-y-2">
                              <Label>Dosis</Label>
                              <Input
                                placeholder="Contoh: 5mg, 500mg"
                                value={medication.dosage}
                                onChange={(e) => updateMedication(index, "dosage", e.target.value)}
                              />
                            </div>
                          </div>
                          <div className="grid md:grid-cols-2 gap-4">
                            <div className="space-y-2">
                              <Label>Frekuensi</Label>
                              <Select
                                value={medication.frequency}
                                onValueChange={(value) => updateMedication(index, "frequency", value)}
                              >
                                <SelectTrigger>
                                  <SelectValue placeholder="Pilih frekuensi" />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="1x sehari">1x sehari</SelectItem>
                                  <SelectItem value="2x sehari">2x sehari</SelectItem>
                                  <SelectItem value="3x sehari">3x sehari</SelectItem>
                                  <SelectItem value="4x sehari">4x sehari</SelectItem>
                                  <SelectItem value="Bila perlu">Bila perlu</SelectItem>
                                </SelectContent>
                              </Select>
                            </div>
                            <div className="space-y-2">
                              <Label>Durasi</Label>
                              <Select
                                value={medication.duration}
                                onValueChange={(value) => updateMedication(index, "duration", value)}
                              >
                                <SelectTrigger>
                                  <SelectValue placeholder="Pilih durasi" />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="3 hari">3 hari</SelectItem>
                                  <SelectItem value="7 hari">7 hari</SelectItem>
                                  <SelectItem value="14 hari">14 hari</SelectItem>
                                  <SelectItem value="30 hari">30 hari</SelectItem>
                                  <SelectItem value="60 hari">60 hari</SelectItem>
                                  <SelectItem value="90 hari">90 hari</SelectItem>
                                </SelectContent>
                              </Select>
                            </div>
                          </div>
                          <div className="space-y-2">
                            <Label>Petunjuk Penggunaan</Label>
                            <Textarea
                              placeholder="Contoh: Diminum setelah makan"
                              value={medication.instructions}
                              onChange={(e) => updateMedication(index, "instructions", e.target.value)}
                            />
                          </div>
                        </div>
                      </Card>
                    ))}
                  </div>

                  {/* Notes */}
                  <div className="space-y-2">
                    <Label htmlFor="notes">Catatan Dokter</Label>
                    <Textarea
                      id="notes"
                      placeholder="Catatan tambahan untuk pasien"
                      value={newPrescription.notes}
                      onChange={(e) => setNewPrescription({ ...newPrescription, notes: e.target.value })}
                    />
                  </div>

                  <div className="flex justify-end space-x-2">
                    <Button variant="outline" onClick={() => setIsCreateModalOpen(false)}>
                      Batal
                    </Button>
                    <Button onClick={createPrescription}>Buat Resep</Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Stats Cards */}
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Total Resep</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{prescriptions.length}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Resep Aktif</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{prescriptions.filter((p) => p.status === "active").length}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Resep Bulan Ini</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {prescriptions.filter((p) => new Date(p.date).getMonth() === new Date().getMonth()).length}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Prescriptions List */}
        <div className="space-y-6">
          {filteredPrescriptions.map((prescription) => (
            <Card key={prescription.id}>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="flex items-center">
                      <Pill className="h-5 w-5 mr-2" />
                      Resep untuk {prescription.patient.name}
                    </CardTitle>
                    <CardDescription>
                      {prescription.diagnosis} • {new Date(prescription.date).toLocaleDateString("id-ID")}
                    </CardDescription>
                  </div>
                  <Badge variant={getStatusColor(prescription.status)}>{getStatusText(prescription.status)}</Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {/* Medications Summary */}
                  <div>
                    <h4 className="font-semibold text-sm text-gray-700 mb-2">Obat yang Diresepkan:</h4>
                    <div className="grid md:grid-cols-2 gap-2">
                      {prescription.medications.map((med: any, index: number) => (
                        <div key={index} className="text-sm bg-blue-50 p-2 rounded">
                          <span className="font-medium">
                            {med.name} {med.dosage}
                          </span>
                          <span className="text-gray-600"> - {med.frequency}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {prescription.notes && (
                    <div>
                      <h4 className="font-semibold text-sm text-gray-700 mb-1">Catatan:</h4>
                      <p className="text-sm text-gray-600">{prescription.notes}</p>
                    </div>
                  )}

                  <div className="flex justify-end space-x-2">
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button variant="outline" size="sm" onClick={() => setSelectedPrescription(prescription)}>
                          <Eye className="h-4 w-4 mr-2" />
                          Lihat Detail
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="sm:max-w-[600px]">
                        <DialogHeader>
                          <DialogTitle>Detail Resep Digital</DialogTitle>
                          <DialogDescription>
                            Resep untuk {selectedPrescription?.patient.name} - {selectedPrescription?.date}
                          </DialogDescription>
                        </DialogHeader>
                        {selectedPrescription && (
                          <div className="space-y-6">
                            {/* Patient Info */}
                            <div>
                              <h4 className="font-semibold text-sm text-gray-700 mb-2">Informasi Pasien</h4>
                              <div className="bg-blue-50 p-4 rounded-lg">
                                <div className="grid md:grid-cols-2 gap-4 text-sm">
                                  <div>
                                    <p>
                                      <strong>Nama:</strong> {selectedPrescription.patient.name}
                                    </p>
                                    <p>
                                      <strong>Umur:</strong> {selectedPrescription.patient.age} tahun
                                    </p>
                                  </div>
                                  <div>
                                    <p>
                                      <strong>Diagnosis:</strong> {selectedPrescription.diagnosis}
                                    </p>
                                    <p>
                                      <strong>Tanggal:</strong>{" "}
                                      {new Date(selectedPrescription.date).toLocaleDateString("id-ID")}
                                    </p>
                                  </div>
                                </div>
                              </div>
                            </div>

                            {/* Medications Detail */}
                            <div>
                              <h4 className="font-semibold text-sm text-gray-700 mb-3">Detail Obat</h4>
                              <div className="space-y-3">
                                {selectedPrescription.medications.map((med: any, index: number) => (
                                  <div key={index} className="border rounded-lg p-4">
                                    <div className="flex items-center justify-between mb-2">
                                      <h5 className="font-semibold">
                                        {med.name} {med.dosage}
                                      </h5>
                                      <Badge variant="outline">{med.frequency}</Badge>
                                    </div>
                                    <div className="grid md:grid-cols-2 gap-4 text-sm">
                                      <div>
                                        <p>
                                          <strong>Durasi:</strong> {med.duration}
                                        </p>
                                      </div>
                                      <div>
                                        <p>
                                          <strong>Petunjuk:</strong> {med.instructions}
                                        </p>
                                      </div>
                                    </div>
                                  </div>
                                ))}
                              </div>
                            </div>

                            {/* Notes */}
                            {selectedPrescription.notes && (
                              <div>
                                <h4 className="font-semibold text-sm text-gray-700 mb-2">Catatan Dokter</h4>
                                <p className="text-sm bg-yellow-50 p-3 rounded-lg">{selectedPrescription.notes}</p>
                              </div>
                            )}
                          </div>
                        )}
                      </DialogContent>
                    </Dialog>

                    <Button size="sm" onClick={() => downloadPrescription(prescription)}>
                      <Download className="h-4 w-4 mr-2" />
                      Download
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}

          {filteredPrescriptions.length === 0 && (
            <Card>
              <CardContent className="text-center py-12">
                <Stethoscope className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">
                  {searchTerm ? "Resep Tidak Ditemukan" : "Belum Ada Resep"}
                </h3>
                <p className="text-gray-600 mb-4">
                  {searchTerm
                    ? "Coba gunakan kata kunci pencarian yang berbeda."
                    : "Mulai buat resep digital untuk pasien Anda."}
                </p>
                <Button onClick={() => setIsCreateModalOpen(true)}>
                  <Plus className="h-4 w-4 mr-2" />
                  Buat Resep Baru
                </Button>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}
