"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Activity, ArrowLeft, Search, Filter, RefreshCw, User, Calendar, CreditCard, UserPlus } from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"

export default function AdminActivities() {
  const [user, setUser] = useState<any>(null)
  const [activities, setActivities] = useState<any[]>([])
  const [filteredActivities, setFilteredActivities] = useState<any[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [typeFilter, setTypeFilter] = useState("all")
  const [statusFilter, setStatusFilter] = useState("all")
  const router = useRouter()

  useEffect(() => {
    const userData = localStorage.getItem("user")
    if (userData) {
      const parsedUser = JSON.parse(userData)
      if (parsedUser.role !== "admin") {
        router.push("/login")
      } else {
        setUser(parsedUser)
        loadActivities()
      }
    } else {
      router.push("/login")
    }
  }, [router])

  useEffect(() => {
    let filtered = activities.filter(
      (activity) =>
        activity.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        activity.user.toLowerCase().includes(searchTerm.toLowerCase()),
    )

    if (typeFilter !== "all") {
      filtered = filtered.filter((activity) => activity.type === typeFilter)
    }

    if (statusFilter !== "all") {
      filtered = filtered.filter((activity) => activity.status === statusFilter)
    }

    setFilteredActivities(filtered)
  }, [searchTerm, typeFilter, statusFilter, activities])

  const loadActivities = () => {
    // Mock data - replace with actual API call
    const mockActivities = [
      {
        id: 1,
        type: "appointment",
        status: "new",
        user: "John Doe",
        userRole: "patient",
        description: "Janji baru dibuat dengan Dr. Sarah Johnson",
        details: "Konsultasi Kardiologi - 15 Jan 2024, 10:00",
        timestamp: new Date(Date.now() - 5 * 60 * 1000), // 5 minutes ago
        ipAddress: "192.168.1.100",
        userAgent: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
      },
      {
        id: 2,
        type: "payment",
        status: "completed",
        user: "Maria Santos",
        userRole: "patient",
        description: "Pembayaran berhasil diproses",
        details: "Rp 500,000 - Transfer Bank BCA",
        timestamp: new Date(Date.now() - 15 * 60 * 1000), // 15 minutes ago
        ipAddress: "192.168.1.101",
        userAgent: "Mozilla/5.0 (iPhone; CPU iPhone OS 14_7_1 like Mac OS X)",
      },
      {
        id: 3,
        type: "registration",
        status: "new",
        user: "Ahmad Wijaya",
        userRole: "patient",
        description: "Pasien baru mendaftar",
        details: "Registrasi akun pasien baru - Email: ahmad.wijaya@email.com",
        timestamp: new Date(Date.now() - 30 * 60 * 1000), // 30 minutes ago
        ipAddress: "192.168.1.102",
        userAgent: "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36",
      },
      {
        id: 4,
        type: "appointment",
        status: "cancelled",
        user: "Lisa Chen",
        userRole: "patient",
        description: "Janji konsultasi dibatalkan",
        details: "Pembatalan janji dengan Dr. Michael Chen - 16 Jan 2024",
        timestamp: new Date(Date.now() - 1 * 60 * 60 * 1000), // 1 hour ago
        ipAddress: "192.168.1.103",
        userAgent: "Mozilla/5.0 (Android 11; Mobile; rv:68.0) Gecko/68.0 Firefox/88.0",
      },
      {
        id: 5,
        type: "login",
        status: "success",
        user: "Dr. Sarah Johnson",
        userRole: "doctor",
        description: "Login berhasil",
        details: "Akses dashboard dokter",
        timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000), // 2 hours ago
        ipAddress: "192.168.1.104",
        userAgent: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
      },
      {
        id: 6,
        type: "medical_record",
        status: "created",
        user: "Dr. Michael Chen",
        userRole: "doctor",
        description: "Rekam medis baru dibuat",
        details: "Rekam medis untuk pasien John Doe - Diagnosis: Hipertensi",
        timestamp: new Date(Date.now() - 3 * 60 * 60 * 1000), // 3 hours ago
        ipAddress: "192.168.1.105",
        userAgent: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
      },
      {
        id: 7,
        type: "system",
        status: "maintenance",
        user: "System Admin",
        userRole: "admin",
        description: "Maintenance sistem terjadwal",
        details: "Backup database dan update sistem",
        timestamp: new Date(Date.now() - 6 * 60 * 60 * 1000), // 6 hours ago
        ipAddress: "127.0.0.1",
        userAgent: "System Process",
      },
      {
        id: 8,
        type: "payment",
        status: "failed",
        user: "Robert Kim",
        userRole: "patient",
        description: "Pembayaran gagal",
        details: "Rp 350,000 - Kartu kredit ditolak",
        timestamp: new Date(Date.now() - 12 * 60 * 60 * 1000), // 12 hours ago
        ipAddress: "192.168.1.106",
        userAgent: "Mozilla/5.0 (iPad; CPU OS 14_7_1 like Mac OS X) AppleWebKit/605.1.15",
      },
    ]
    setActivities(mockActivities)
    setFilteredActivities(mockActivities)
  }

  const refreshActivities = () => {
    loadActivities()
    alert("Aktivitas berhasil diperbarui!")
  }

  const getActivityIcon = (type: string) => {
    switch (type) {
      case "appointment":
        return <Calendar className="h-4 w-4" />
      case "payment":
        return <CreditCard className="h-4 w-4" />
      case "registration":
        return <UserPlus className="h-4 w-4" />
      case "login":
        return <User className="h-4 w-4" />
      case "medical_record":
        return <Activity className="h-4 w-4" />
      case "system":
        return <RefreshCw className="h-4 w-4" />
      default:
        return <Activity className="h-4 w-4" />
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "new":
        return "default"
      case "completed":
      case "success":
      case "created":
        return "outline"
      case "cancelled":
      case "failed":
        return "destructive"
      case "maintenance":
        return "secondary"
      default:
        return "outline"
    }
  }

  const getStatusText = (status: string) => {
    switch (status) {
      case "new":
        return "Baru"
      case "completed":
        return "Selesai"
      case "success":
        return "Berhasil"
      case "created":
        return "Dibuat"
      case "cancelled":
        return "Dibatalkan"
      case "failed":
        return "Gagal"
      case "maintenance":
        return "Maintenance"
      default:
        return status
    }
  }

  const getTypeText = (type: string) => {
    switch (type) {
      case "appointment":
        return "Janji Konsultasi"
      case "payment":
        return "Pembayaran"
      case "registration":
        return "Registrasi"
      case "login":
        return "Login"
      case "medical_record":
        return "Rekam Medis"
      case "system":
        return "Sistem"
      default:
        return type
    }
  }

  const formatTimeAgo = (timestamp: Date) => {
    const now = new Date()
    const diffInMinutes = Math.floor((now.getTime() - timestamp.getTime()) / (1000 * 60))

    if (diffInMinutes < 1) return "Baru saja"
    if (diffInMinutes < 60) return `${diffInMinutes} menit lalu`

    const diffInHours = Math.floor(diffInMinutes / 60)
    if (diffInHours < 24) return `${diffInHours} jam lalu`

    const diffInDays = Math.floor(diffInHours / 24)
    return `${diffInDays} hari lalu`
  }

  if (!user) return null

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="sm" asChild>
              <Link href="/admin/dashboard">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Kembali
              </Link>
            </Button>
            <h1 className="text-2xl font-bold text-gray-900">Log Aktivitas Sistem</h1>
          </div>
          <Button onClick={refreshActivities}>
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Filters */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Filter className="h-5 w-5 mr-2" />
              Filter & Pencarian
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-4 gap-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  placeholder="Cari aktivitas atau pengguna..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Select value={typeFilter} onValueChange={setTypeFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Filter Jenis" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Semua Jenis</SelectItem>
                  <SelectItem value="appointment">Janji Konsultasi</SelectItem>
                  <SelectItem value="payment">Pembayaran</SelectItem>
                  <SelectItem value="registration">Registrasi</SelectItem>
                  <SelectItem value="login">Login</SelectItem>
                  <SelectItem value="medical_record">Rekam Medis</SelectItem>
                  <SelectItem value="system">Sistem</SelectItem>
                </SelectContent>
              </Select>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Filter Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Semua Status</SelectItem>
                  <SelectItem value="new">Baru</SelectItem>
                  <SelectItem value="completed">Selesai</SelectItem>
                  <SelectItem value="success">Berhasil</SelectItem>
                  <SelectItem value="failed">Gagal</SelectItem>
                  <SelectItem value="cancelled">Dibatalkan</SelectItem>
                </SelectContent>
              </Select>
              <Button
                variant="outline"
                onClick={() => {
                  setSearchTerm("")
                  setTypeFilter("all")
                  setStatusFilter("all")
                }}
              >
                Reset Filter
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Stats Cards */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Total Aktivitas</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{activities.length}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Aktivitas Hari Ini</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {
                  activities.filter((a) => {
                    const today = new Date()
                    const activityDate = new Date(a.timestamp)
                    return activityDate.toDateString() === today.toDateString()
                  }).length
                }
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Aktivitas Berhasil</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {activities.filter((a) => a.status === "success" || a.status === "completed").length}
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Aktivitas Gagal</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {activities.filter((a) => a.status === "failed" || a.status === "cancelled").length}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Activities List */}
        <div className="space-y-4">
          {filteredActivities.map((activity) => (
            <Card key={activity.id}>
              <CardContent className="p-6">
                <div className="flex items-start space-x-4">
                  <div
                    className={`p-2 rounded-full ${
                      activity.status === "failed" || activity.status === "cancelled"
                        ? "bg-red-100 text-red-600"
                        : activity.status === "new"
                          ? "bg-blue-100 text-blue-600"
                          : "bg-green-100 text-green-600"
                    }`}
                  >
                    {getActivityIcon(activity.type)}
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center space-x-2">
                        <h3 className="text-sm font-semibold text-gray-900">{activity.description}</h3>
                        <Badge variant={getStatusColor(activity.status)}>{getStatusText(activity.status)}</Badge>
                        <Badge variant="outline">{getTypeText(activity.type)}</Badge>
                      </div>
                      <span className="text-sm text-gray-500">{formatTimeAgo(activity.timestamp)}</span>
                    </div>

                    <p className="text-sm text-gray-600 mb-3">{activity.details}</p>

                    <div className="grid md:grid-cols-3 gap-4 text-xs text-gray-500">
                      <div>
                        <span className="font-medium">Pengguna: </span>
                        <span>
                          {activity.user} ({activity.userRole})
                        </span>
                      </div>
                      <div>
                        <span className="font-medium">IP Address: </span>
                        <span>{activity.ipAddress}</span>
                      </div>
                      <div>
                        <span className="font-medium">Waktu: </span>
                        <span>{activity.timestamp.toLocaleString("id-ID")}</span>
                      </div>
                    </div>

                    <div className="mt-2 text-xs text-gray-400 truncate">
                      <span className="font-medium">User Agent: </span>
                      <span>{activity.userAgent}</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}

          {filteredActivities.length === 0 && (
            <Card>
              <CardContent className="text-center py-12">
                <Activity className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">
                  {searchTerm || typeFilter !== "all" || statusFilter !== "all"
                    ? "Tidak Ada Aktivitas Ditemukan"
                    : "Belum Ada Aktivitas"}
                </h3>
                <p className="text-gray-600">
                  {searchTerm || typeFilter !== "all" || statusFilter !== "all"
                    ? "Coba ubah filter pencarian Anda."
                    : "Aktivitas sistem akan muncul di sini."}
                </p>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Real-time Activity Feed */}
        <Card className="mt-8">
          <CardHeader>
            <CardTitle className="flex items-center">
              <RefreshCw className="h-5 w-5 mr-2" />
              Aktivitas Real-time
            </CardTitle>
            <CardDescription>Monitor aktivitas sistem secara langsung (diperbarui setiap 30 detik)</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {activities.slice(0, 5).map((activity) => (
                <div key={activity.id} className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                  <div
                    className={`w-2 h-2 rounded-full ${
                      activity.status === "failed" || activity.status === "cancelled"
                        ? "bg-red-500"
                        : activity.status === "new"
                          ? "bg-blue-500"
                          : "bg-green-500"
                    }`}
                  />
                  <div className="flex-1">
                    <p className="text-sm font-medium">{activity.description}</p>
                    <p className="text-xs text-gray-500">
                      {activity.user} • {formatTimeAgo(activity.timestamp)}
                    </p>
                  </div>
                  <Badge variant="outline" className="text-xs">
                    {getTypeText(activity.type)}
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
