"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Users, Calendar, FileText, TrendingUp, User, LogOut, Bell, Activity } from "lucide-react"
import { useRouter } from "next/navigation"

export default function AdminDashboard() {
  const [user, setUser] = useState<any>(null)
  const router = useRouter()

  useEffect(() => {
    const userData = localStorage.getItem("user")
    if (userData) {
      const parsedUser = JSON.parse(userData)
      if (parsedUser.role !== "admin") {
        router.push("/login")
      } else {
        setUser(parsedUser)
      }
    } else {
      router.push("/login")
    }
  }, [router])

  const handleLogout = () => {
    localStorage.removeItem("user")
    router.push("/")
  }

  if (!user) return null

  const stats = [
    {
      title: "Total Pasien",
      value: "1,234",
      change: "+12%",
      icon: Users,
      color: "text-blue-600",
    },
    {
      title: "Janji Hari Ini",
      value: "45",
      change: "+5%",
      icon: Calendar,
      color: "text-green-600",
    },
    {
      title: "Dokter Aktif",
      value: "28",
      change: "+2%",
      icon: Activity,
      color: "text-purple-600",
    },
    {
      title: "Pendapatan Bulan Ini",
      value: "Rp 125M",
      change: "+18%",
      icon: TrendingUp,
      color: "text-orange-600",
    },
  ]

  const recentActivities = [
    {
      id: 1,
      type: "appointment",
      message: "Janji baru dibuat oleh John Doe dengan Dr. Sarah",
      time: "5 menit lalu",
      status: "new",
    },
    {
      id: 2,
      type: "payment",
      message: "Pembayaran Rp 500,000 diterima dari Maria Santos",
      time: "15 menit lalu",
      status: "completed",
    },
    {
      id: 3,
      type: "registration",
      message: "Pasien baru terdaftar: Ahmad Wijaya",
      time: "30 menit lalu",
      status: "new",
    },
    {
      id: 4,
      type: "appointment",
      message: "Janji dibatalkan oleh Lisa Chen",
      time: "1 jam lalu",
      status: "cancelled",
    },
  ]

  const todayAppointments = [
    {
      id: 1,
      time: "09:00",
      patient: "John Doe",
      doctor: "Dr. Sarah Johnson",
      type: "Konsultasi",
      status: "confirmed",
    },
    {
      id: 2,
      time: "10:30",
      patient: "Maria Santos",
      doctor: "Dr. Michael Chen",
      type: "Pemeriksaan",
      status: "in-progress",
    },
    {
      id: 3,
      time: "14:00",
      patient: "Ahmad Wijaya",
      doctor: "Dr. Lisa Wong",
      type: "Follow-up",
      status: "pending",
    },
  ]

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <img src="/images/hospital-logo.png" alt="PERSADA SARI HUSNA Medical Center" className="h-10 w-10" />
            <h1 className="text-2xl font-bold text-gray-900">Dashboard Admin</h1>
          </div>
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="sm">
              <Bell className="h-4 w-4" />
            </Button>
            <div className="flex items-center space-x-2">
              <User className="h-5 w-5 text-gray-600" />
              <span className="text-sm font-medium">{user.name}</span>
            </div>
            <Button variant="outline" size="sm" onClick={handleLogout}>
              <LogOut className="h-4 w-4 mr-2" />
              Keluar
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-2">Selamat datang, {user.name}!</h2>
          <p className="text-gray-600">Kelola operasional rumah sakit dan monitor aktivitas sistem</p>
        </div>

        {/* Stats Cards */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => (
            <Card key={index}>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">{stat.title}</CardTitle>
                <stat.icon className={`h-4 w-4 ${stat.color}`} />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stat.value}</div>
                <p className="text-xs text-muted-foreground">
                  <span className="text-green-600">{stat.change}</span> dari bulan lalu
                </p>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Today's Appointments */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Calendar className="h-5 w-5 mr-2" />
                Jadwal Hari Ini
              </CardTitle>
              <CardDescription>Daftar janji konsultasi yang dijadwalkan hari ini</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {todayAppointments.map((appointment) => (
                  <div key={appointment.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div>
                      <div className="flex items-center space-x-2">
                        <span className="font-semibold">{appointment.time}</span>
                        <Badge variant="outline">{appointment.type}</Badge>
                      </div>
                      <p className="text-sm text-gray-600 mt-1">
                        {appointment.patient} • {appointment.doctor}
                      </p>
                    </div>
                    <Badge
                      variant={
                        appointment.status === "confirmed"
                          ? "default"
                          : appointment.status === "in-progress"
                            ? "secondary"
                            : "outline"
                      }
                    >
                      {appointment.status === "confirmed"
                        ? "Dikonfirmasi"
                        : appointment.status === "in-progress"
                          ? "Berlangsung"
                          : "Menunggu"}
                    </Badge>
                  </div>
                ))}
                <Button variant="outline" className="w-full" onClick={() => router.push("/admin/appointments")}>
                  Lihat Semua Jadwal
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Recent Activities */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Activity className="h-5 w-5 mr-2" />
                Aktivitas Terbaru
              </CardTitle>
              <CardDescription>Monitor aktivitas sistem secara real-time</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentActivities.map((activity) => (
                  <div key={activity.id} className="flex items-start space-x-3 p-3 border rounded-lg">
                    <div
                      className={`w-2 h-2 rounded-full mt-2 ${
                        activity.status === "new"
                          ? "bg-blue-500"
                          : activity.status === "completed"
                            ? "bg-green-500"
                            : "bg-red-500"
                      }`}
                    />
                    <div className="flex-1">
                      <p className="text-sm">{activity.message}</p>
                      <p className="text-xs text-gray-500 mt-1">{activity.time}</p>
                    </div>
                  </div>
                ))}
                <Button variant="outline" className="w-full" onClick={() => router.push("/admin/activities")}>
                  Lihat Semua Aktivitas
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Management Actions */}
        <div className="grid md:grid-cols-3 gap-6 mt-8">
          <Card
            className="hover:shadow-lg transition-shadow cursor-pointer"
            onClick={() => router.push("/admin/patients")}
          >
            <CardHeader>
              <Users className="h-8 w-8 text-blue-600 mb-2" />
              <CardTitle>Manajemen Pasien</CardTitle>
              <CardDescription>Kelola data pasien, registrasi, dan profil</CardDescription>
            </CardHeader>
          </Card>

          <Card
            className="hover:shadow-lg transition-shadow cursor-pointer"
            onClick={() => router.push("/admin/doctors")}
          >
            <CardHeader>
              <Activity className="h-8 w-8 text-green-600 mb-2" />
              <CardTitle>Manajemen Dokter</CardTitle>
              <CardDescription>Kelola jadwal dokter dan spesialisasi</CardDescription>
            </CardHeader>
          </Card>

          <Card
            className="hover:shadow-lg transition-shadow cursor-pointer"
            onClick={() => router.push("/admin/reports")}
          >
            <CardHeader>
              <FileText className="h-8 w-8 text-purple-600 mb-2" />
              <CardTitle>Laporan & Analitik</CardTitle>
              <CardDescription>Lihat laporan keuangan dan statistik</CardDescription>
            </CardHeader>
          </Card>
        </div>
      </div>
    </div>
  )
}
