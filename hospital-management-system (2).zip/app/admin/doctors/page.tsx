"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Activity, ArrowLeft, Search, Eye, Calendar, Clock, Users } from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"

export default function AdminDoctors() {
  const [user, setUser] = useState<any>(null)
  const [doctors, setDoctors] = useState<any[]>([])
  const [filteredDoctors, setFilteredDoctors] = useState<any[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedDoctor, setSelectedDoctor] = useState<any>(null)
  const [selectedDoctorSchedule, setSelectedDoctorSchedule] = useState<any[]>([])
  const router = useRouter()

  useEffect(() => {
    const userData = localStorage.getItem("user")
    if (userData) {
      const parsedUser = JSON.parse(userData)
      if (parsedUser.role !== "admin") {
        router.push("/login")
      } else {
        setUser(parsedUser)
        loadDoctors()
      }
    } else {
      router.push("/login")
    }
  }, [router])

  useEffect(() => {
    const filtered = doctors.filter(
      (doctor) =>
        doctor.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        doctor.specialty.toLowerCase().includes(searchTerm.toLowerCase()) ||
        doctor.email.toLowerCase().includes(searchTerm.toLowerCase()),
    )
    setFilteredDoctors(filtered)
  }, [searchTerm, doctors])

  const loadDoctors = () => {
    // Mock data - replace with actual API call
    const mockDoctors = [
      {
        id: 1,
        name: "Dr. Sarah Johnson",
        email: "sarah.johnson@hospital.com",
        phone: "081234567801",
        specialty: "Kardiologi",
        licenseNumber: "DOC001",
        experience: 10,
        education: "S1 Kedokteran Universitas Indonesia, Sp.JP Universitas Gadjah Mada",
        consultationFee: 500000,
        isAvailable: true,
        joinDate: "2020-01-15",
        totalPatients: 245,
        completedConsultations: 1250,
        rating: 4.8,
        workingDays: ["Senin", "Selasa", "Rabu", "Kamis", "Jumat"],
        workingHours: "09:00 - 17:00",
        currentPatients: [
          { id: 1, name: "John Doe", nextAppointment: "2024-01-15 10:00", condition: "Hipertensi" },
          { id: 2, name: "Maria Santos", nextAppointment: "2024-01-16 14:00", condition: "Aritmia" },
        ],
      },
      {
        id: 2,
        name: "Dr. Michael Chen",
        email: "michael.chen@hospital.com",
        phone: "081234567802",
        specialty: "Dermatologi",
        licenseNumber: "DOC002",
        experience: 8,
        education: "S1 Kedokteran Universitas Airlangga, Sp.KK Universitas Padjadjaran",
        consultationFee: 400000,
        isAvailable: true,
        joinDate: "2021-03-20",
        totalPatients: 189,
        completedConsultations: 890,
        rating: 4.7,
        workingDays: ["Senin", "Rabu", "Jumat", "Sabtu"],
        workingHours: "10:00 - 16:00",
        currentPatients: [
          { id: 3, name: "Ahmad Wijaya", nextAppointment: "2024-01-15 11:00", condition: "Dermatitis" },
          { id: 4, name: "Lisa Chen", nextAppointment: "2024-01-17 09:00", condition: "Acne" },
        ],
      },
      {
        id: 3,
        name: "Dr. Lisa Wong",
        email: "lisa.wong@hospital.com",
        phone: "081234567803",
        specialty: "Gizi",
        licenseNumber: "DOC003",
        experience: 6,
        education: "S1 Gizi Universitas Indonesia, S2 Gizi Klinik IPB",
        consultationFee: 350000,
        isAvailable: true,
        joinDate: "2022-06-10",
        totalPatients: 156,
        completedConsultations: 678,
        rating: 4.9,
        workingDays: ["Selasa", "Kamis", "Sabtu"],
        workingHours: "08:00 - 15:00",
        currentPatients: [{ id: 5, name: "Robert Kim", nextAppointment: "2024-01-16 10:00", condition: "Obesitas" }],
      },
      {
        id: 4,
        name: "Dr. Ahmad Rizki",
        email: "ahmad.rizki@hospital.com",
        phone: "081234567804",
        specialty: "Penyakit Dalam",
        licenseNumber: "DOC004",
        experience: 12,
        education: "S1 Kedokteran Universitas Gadjah Mada, Sp.PD Universitas Indonesia",
        consultationFee: 450000,
        isAvailable: false,
        joinDate: "2019-09-01",
        totalPatients: 312,
        completedConsultations: 1567,
        rating: 4.6,
        workingDays: ["Senin", "Selasa", "Kamis", "Jumat"],
        workingHours: "08:00 - 16:00",
        currentPatients: [],
      },
    ]
    setDoctors(mockDoctors)
    setFilteredDoctors(mockDoctors)
  }

  const loadDoctorSchedule = (doctorId: number) => {
    // Mock schedule data for the selected doctor
    const mockSchedule = [
      {
        id: 1,
        date: "2024-01-15",
        time: "09:00",
        patient: { name: "John Doe", condition: "Hipertensi", phone: "081234567890" },
        status: "confirmed",
        duration: 30,
      },
      {
        id: 2,
        date: "2024-01-15",
        time: "10:00",
        patient: { name: "Maria Santos", condition: "Aritmia", phone: "081234567892" },
        status: "pending",
        duration: 45,
      },
      {
        id: 3,
        date: "2024-01-16",
        time: "14:00",
        patient: { name: "Ahmad Wijaya", condition: "Dermatitis", phone: "081234567894" },
        status: "confirmed",
        duration: 30,
      },
    ]
    setSelectedDoctorSchedule(mockSchedule)
  }

  const toggleDoctorAvailability = (doctorId: number) => {
    const updatedDoctors = doctors.map((doctor) =>
      doctor.id === doctorId ? { ...doctor, isAvailable: !doctor.isAvailable } : doctor,
    )
    setDoctors(updatedDoctors)
    setFilteredDoctors(updatedDoctors)

    const doctor = updatedDoctors.find((d) => d.id === doctorId)
    alert(`Dr. ${doctor?.name} ${doctor?.isAvailable ? "diaktifkan" : "dinonaktifkan"}`)
  }

  const getStatusColor = (isAvailable: boolean) => {
    return isAvailable ? "default" : "secondary"
  }

  const getStatusText = (isAvailable: boolean) => {
    return isAvailable ? "Aktif" : "Tidak Aktif"
  }

  if (!user) return null

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="sm" asChild>
              <Link href="/admin/dashboard">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Kembali
              </Link>
            </Button>
            <h1 className="text-2xl font-bold text-gray-900">Manajemen Dokter</h1>
          </div>
          <div className="flex items-center space-x-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="Cari dokter..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 w-64"
              />
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Stats Cards */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Total Dokter</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{doctors.length}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Dokter Aktif</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{doctors.filter((d) => d.isAvailable).length}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Total Konsultasi</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{doctors.reduce((sum, d) => sum + d.completedConsultations, 0)}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Rating Rata-rata</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {(doctors.reduce((sum, d) => sum + d.rating, 0) / doctors.length).toFixed(1)}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Doctors List */}
        <div className="space-y-6">
          {filteredDoctors.map((doctor) => (
            <Card key={doctor.id}>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="flex items-center">
                      <Activity className="h-5 w-5 mr-2" />
                      {doctor.name}
                    </CardTitle>
                    <CardDescription>
                      {doctor.specialty} • {doctor.experience} tahun pengalaman
                    </CardDescription>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Badge variant={getStatusColor(doctor.isAvailable)}>{getStatusText(doctor.isAvailable)}</Badge>
                    <div className="text-right">
                      <div className="text-sm text-gray-600">Rating</div>
                      <div className="font-semibold">⭐ {doctor.rating}</div>
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-4 gap-4 mb-4">
                  <div>
                    <p className="text-sm text-gray-600">Kontak</p>
                    <p className="font-semibold">{doctor.phone}</p>
                    <p className="text-sm text-gray-600">{doctor.email}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Tarif Konsultasi</p>
                    <p className="font-semibold">Rp {doctor.consultationFee.toLocaleString()}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Total Pasien</p>
                    <p className="font-semibold">{doctor.totalPatients} pasien</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Jam Kerja</p>
                    <p className="font-semibold">{doctor.workingHours}</p>
                  </div>
                </div>

                <div className="flex justify-end space-x-2">
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          setSelectedDoctor(doctor)
                          loadDoctorSchedule(doctor.id)
                        }}
                      >
                        <Eye className="h-4 w-4 mr-2" />
                        Detail & Jadwal
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="sm:max-w-[800px]">
                      <DialogHeader>
                        <DialogTitle>Detail Dokter - {selectedDoctor?.name}</DialogTitle>
                        <DialogDescription>Informasi lengkap dokter dan jadwal praktik</DialogDescription>
                      </DialogHeader>
                      {selectedDoctor && (
                        <div className="space-y-6">
                          {/* Doctor Details */}
                          <div className="grid md:grid-cols-2 gap-6">
                            <div>
                              <h4 className="font-semibold text-sm text-gray-700 mb-3">Informasi Pribadi</h4>
                              <div className="space-y-2 text-sm">
                                <div className="flex justify-between">
                                  <span className="text-gray-600">Nama:</span>
                                  <span className="font-medium">{selectedDoctor.name}</span>
                                </div>
                                <div className="flex justify-between">
                                  <span className="text-gray-600">Email:</span>
                                  <span className="font-medium">{selectedDoctor.email}</span>
                                </div>
                                <div className="flex justify-between">
                                  <span className="text-gray-600">Telepon:</span>
                                  <span className="font-medium">{selectedDoctor.phone}</span>
                                </div>
                                <div className="flex justify-between">
                                  <span className="text-gray-600">No. Lisensi:</span>
                                  <span className="font-medium">{selectedDoctor.licenseNumber}</span>
                                </div>
                                <div className="flex justify-between">
                                  <span className="text-gray-600">Bergabung:</span>
                                  <span className="font-medium">
                                    {new Date(selectedDoctor.joinDate).toLocaleDateString("id-ID")}
                                  </span>
                                </div>
                              </div>
                            </div>
                            <div>
                              <h4 className="font-semibold text-sm text-gray-700 mb-3">Informasi Profesional</h4>
                              <div className="space-y-2 text-sm">
                                <div className="flex justify-between">
                                  <span className="text-gray-600">Spesialisasi:</span>
                                  <span className="font-medium">{selectedDoctor.specialty}</span>
                                </div>
                                <div className="flex justify-between">
                                  <span className="text-gray-600">Pengalaman:</span>
                                  <span className="font-medium">{selectedDoctor.experience} tahun</span>
                                </div>
                                <div className="flex justify-between">
                                  <span className="text-gray-600">Tarif:</span>
                                  <span className="font-medium">
                                    Rp {selectedDoctor.consultationFee.toLocaleString()}
                                  </span>
                                </div>
                                <div className="flex justify-between">
                                  <span className="text-gray-600">Rating:</span>
                                  <span className="font-medium">⭐ {selectedDoctor.rating}</span>
                                </div>
                                <div className="flex justify-between">
                                  <span className="text-gray-600">Status:</span>
                                  <Badge variant={getStatusColor(selectedDoctor.isAvailable)}>
                                    {getStatusText(selectedDoctor.isAvailable)}
                                  </Badge>
                                </div>
                              </div>
                            </div>
                          </div>

                          {/* Education */}
                          <div>
                            <h4 className="font-semibold text-sm text-gray-700 mb-2">Pendidikan</h4>
                            <p className="text-sm bg-gray-50 p-3 rounded-lg">{selectedDoctor.education}</p>
                          </div>

                          {/* Working Schedule */}
                          <div>
                            <h4 className="font-semibold text-sm text-gray-700 mb-3">Jadwal Kerja</h4>
                            <div className="grid md:grid-cols-2 gap-4">
                              <div>
                                <p className="text-sm text-gray-600 mb-2">Hari Kerja:</p>
                                <div className="flex flex-wrap gap-1">
                                  {selectedDoctor.workingDays.map((day: string) => (
                                    <Badge key={day} variant="outline" className="text-xs">
                                      {day}
                                    </Badge>
                                  ))}
                                </div>
                              </div>
                              <div>
                                <p className="text-sm text-gray-600 mb-2">Jam Kerja:</p>
                                <div className="flex items-center space-x-2">
                                  <Clock className="h-4 w-4 text-gray-500" />
                                  <span className="text-sm font-medium">{selectedDoctor.workingHours}</span>
                                </div>
                              </div>
                            </div>
                          </div>

                          {/* Current Patients */}
                          <div>
                            <h4 className="font-semibold text-sm text-gray-700 mb-3">
                              Pasien Aktif ({selectedDoctor.currentPatients.length})
                            </h4>
                            {selectedDoctor.currentPatients.length > 0 ? (
                              <div className="space-y-2">
                                {selectedDoctor.currentPatients.map((patient: any) => (
                                  <div
                                    key={patient.id}
                                    className="flex items-center justify-between p-3 bg-blue-50 rounded-lg"
                                  >
                                    <div>
                                      <div className="flex items-center space-x-2">
                                        <Users className="h-4 w-4 text-blue-600" />
                                        <span className="font-medium">{patient.name}</span>
                                      </div>
                                      <p className="text-sm text-gray-600 ml-6">{patient.condition}</p>
                                    </div>
                                    <div className="text-right">
                                      <p className="text-sm text-gray-600">Janji Berikutnya</p>
                                      <p className="text-sm font-medium">
                                        {new Date(patient.nextAppointment).toLocaleString("id-ID")}
                                      </p>
                                    </div>
                                  </div>
                                ))}
                              </div>
                            ) : (
                              <p className="text-sm text-gray-500 italic">Tidak ada pasien aktif saat ini</p>
                            )}
                          </div>

                          {/* Recent Schedule */}
                          <div>
                            <h4 className="font-semibold text-sm text-gray-700 mb-3">Jadwal Mendatang</h4>
                            {selectedDoctorSchedule.length > 0 ? (
                              <div className="space-y-2 max-h-40 overflow-y-auto">
                                {selectedDoctorSchedule.map((appointment) => (
                                  <div
                                    key={appointment.id}
                                    className="flex items-center justify-between p-3 border rounded-lg"
                                  >
                                    <div>
                                      <div className="flex items-center space-x-2">
                                        <Calendar className="h-4 w-4 text-green-600" />
                                        <span className="font-medium">
                                          {new Date(appointment.date).toLocaleDateString("id-ID")} - {appointment.time}
                                        </span>
                                      </div>
                                      <p className="text-sm text-gray-600 ml-6">
                                        {appointment.patient.name} • {appointment.patient.condition}
                                      </p>
                                    </div>
                                    <Badge variant={appointment.status === "confirmed" ? "default" : "secondary"}>
                                      {appointment.status === "confirmed" ? "Dikonfirmasi" : "Menunggu"}
                                    </Badge>
                                  </div>
                                ))}
                              </div>
                            ) : (
                              <p className="text-sm text-gray-500 italic">Tidak ada jadwal mendatang</p>
                            )}
                          </div>

                          {/* Statistics */}
                          <div className="grid md:grid-cols-3 gap-4 pt-4 border-t">
                            <div className="text-center p-3 bg-blue-50 rounded-lg">
                              <div className="text-2xl font-bold text-blue-600">{selectedDoctor.totalPatients}</div>
                              <div className="text-sm text-gray-600">Total Pasien</div>
                            </div>
                            <div className="text-center p-3 bg-green-50 rounded-lg">
                              <div className="text-2xl font-bold text-green-600">
                                {selectedDoctor.completedConsultations}
                              </div>
                              <div className="text-sm text-gray-600">Konsultasi Selesai</div>
                            </div>
                            <div className="text-center p-3 bg-purple-50 rounded-lg">
                              <div className="text-2xl font-bold text-purple-600">{selectedDoctor.rating}</div>
                              <div className="text-sm text-gray-600">Rating</div>
                            </div>
                          </div>
                        </div>
                      )}
                    </DialogContent>
                  </Dialog>

                  <Button variant="outline" size="sm" onClick={() => toggleDoctorAvailability(doctor.id)}>
                    {doctor.isAvailable ? "Nonaktifkan" : "Aktifkan"}
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}

          {filteredDoctors.length === 0 && (
            <Card>
              <CardContent className="text-center py-12">
                <Activity className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">
                  {searchTerm ? "Dokter Tidak Ditemukan" : "Belum Ada Data Dokter"}
                </h3>
                <p className="text-gray-600">
                  {searchTerm
                    ? "Coba gunakan kata kunci pencarian yang berbeda."
                    : "Data dokter akan muncul setelah ada registrasi dokter."}
                </p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}
