"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Calendar, ArrowLeft, Search, Eye, Filter, Download, Clock, User } from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"

export default function AdminAppointments() {
  const [user, setUser] = useState<any>(null)
  const [appointments, setAppointments] = useState<any[]>([])
  const [filteredAppointments, setFilteredAppointments] = useState<any[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [dateFilter, setDateFilter] = useState("all")
  const [selectedAppointment, setSelectedAppointment] = useState<any>(null)
  const router = useRouter()

  useEffect(() => {
    const userData = localStorage.getItem("user")
    if (userData) {
      const parsedUser = JSON.parse(userData)
      if (parsedUser.role !== "admin") {
        router.push("/login")
      } else {
        setUser(parsedUser)
        loadAppointments()
      }
    } else {
      router.push("/login")
    }
  }, [router])

  useEffect(() => {
    let filtered = appointments.filter(
      (appointment) =>
        appointment.patient.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        appointment.doctor.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        appointment.type.toLowerCase().includes(searchTerm.toLowerCase()),
    )

    if (statusFilter !== "all") {
      filtered = filtered.filter((appointment) => appointment.status === statusFilter)
    }

    if (dateFilter !== "all") {
      const today = new Date()

      switch (dateFilter) {
        case "today":
          filtered = filtered.filter((appointment) => {
            const appointmentDate = new Date(appointment.date)
            return appointmentDate.toDateString() === today.toDateString()
          })
          break
        case "week":
          const weekFromNow = new Date(today.getTime() + 7 * 24 * 60 * 60 * 1000)
          filtered = filtered.filter((appointment) => {
            const appointmentDate = new Date(appointment.date)
            return appointmentDate >= today && appointmentDate <= weekFromNow
          })
          break
        case "month":
          const monthFromNow = new Date(today.getFullYear(), today.getMonth() + 1, today.getDate())
          filtered = filtered.filter((appointment) => {
            const appointmentDate = new Date(appointment.date)
            return appointmentDate >= today && appointmentDate <= monthFromNow
          })
          break
      }
    }

    setFilteredAppointments(filtered)
  }, [searchTerm, statusFilter, dateFilter, appointments])

  const loadAppointments = () => {
    // Mock data - replace with actual API call
    const mockAppointments = [
      {
        id: 1,
        date: "2024-01-15",
        time: "09:00",
        duration: 30,
        type: "Konsultasi",
        status: "confirmed",
        patient: {
          id: 1,
          name: "John Doe",
          age: 34,
          phone: "081234567890",
          email: "john.doe@email.com",
          condition: "Hipertensi",
        },
        doctor: {
          id: 1,
          name: "Dr. Sarah Johnson",
          specialty: "Kardiologi",
          phone: "081234567801",
        },
        notes: "Konsultasi rutin hipertensi",
        cost: 500000,
        paymentStatus: "paid",
        createdAt: "2024-01-10",
      },
      {
        id: 2,
        date: "2024-01-15",
        time: "10:30",
        duration: 45,
        type: "Pemeriksaan",
        status: "pending",
        patient: {
          id: 2,
          name: "Maria Santos",
          age: 28,
          phone: "081234567892",
          email: "maria.santos@email.com",
          condition: "Diabetes Type 2",
        },
        doctor: {
          id: 2,
          name: "Dr. Michael Chen",
          specialty: "Dermatologi",
          phone: "081234567802",
        },
        notes: "Pemeriksaan lanjutan diabetes",
        cost: 400000,
        paymentStatus: "pending",
        createdAt: "2024-01-12",
      },
      {
        id: 3,
        date: "2024-01-16",
        time: "14:00",
        duration: 30,
        type: "Follow-up",
        status: "completed",
        patient: {
          id: 3,
          name: "Ahmad Wijaya",
          age: 45,
          phone: "081234567894",
          email: "ahmad.wijaya@email.com",
          condition: "Pemeriksaan Rutin",
        },
        doctor: {
          id: 3,
          name: "Dr. Lisa Wong",
          specialty: "Gizi",
          phone: "081234567803",
        },
        notes: "Follow-up program diet",
        cost: 350000,
        paymentStatus: "paid",
        createdAt: "2024-01-13",
      },
      {
        id: 4,
        date: "2024-01-17",
        time: "11:00",
        duration: 60,
        type: "Konsultasi",
        status: "cancelled",
        patient: {
          id: 4,
          name: "Lisa Chen",
          age: 31,
          phone: "081234567896",
          email: "lisa.chen@email.com",
          condition: "Dermatitis",
        },
        doctor: {
          id: 4,
          name: "Dr. Ahmad Rizki",
          specialty: "Penyakit Dalam",
          phone: "081234567804",
        },
        notes: "Dibatalkan oleh pasien",
        cost: 450000,
        paymentStatus: "refunded",
        createdAt: "2024-01-14",
      },
    ]
    setAppointments(mockAppointments)
    setFilteredAppointments(mockAppointments)
  }

  const updateAppointmentStatus = (appointmentId: number, newStatus: string) => {
    const updatedAppointments = appointments.map((appointment) =>
      appointment.id === appointmentId ? { ...appointment, status: newStatus } : appointment,
    )
    setAppointments(updatedAppointments)
    setFilteredAppointments(updatedAppointments)
    alert(`Status janji berhasil diubah menjadi ${newStatus}`)
  }

  const exportAppointments = () => {
    const csvContent = [
      ["Tanggal", "Waktu", "Pasien", "Dokter", "Jenis", "Status", "Biaya", "Status Pembayaran", "Catatan"],
      ...filteredAppointments.map((a) => [
        a.date,
        a.time,
        a.patient.name,
        a.doctor.name,
        a.type,
        a.status,
        a.cost,
        a.paymentStatus,
        a.notes,
      ]),
    ]
      .map((row) => row.join(","))
      .join("\n")

    const blob = new Blob([csvContent], { type: "text/csv" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `jadwal-konsultasi-${new Date().toISOString().split("T")[0]}.csv`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "confirmed":
        return "default"
      case "pending":
        return "secondary"
      case "completed":
        return "outline"
      case "cancelled":
        return "destructive"
      default:
        return "outline"
    }
  }

  const getStatusText = (status: string) => {
    switch (status) {
      case "confirmed":
        return "Dikonfirmasi"
      case "pending":
        return "Menunggu"
      case "completed":
        return "Selesai"
      case "cancelled":
        return "Dibatalkan"
      default:
        return status
    }
  }

  const getPaymentStatusColor = (status: string) => {
    switch (status) {
      case "paid":
        return "default"
      case "pending":
        return "secondary"
      case "refunded":
        return "outline"
      default:
        return "outline"
    }
  }

  const getPaymentStatusText = (status: string) => {
    switch (status) {
      case "paid":
        return "Lunas"
      case "pending":
        return "Belum Bayar"
      case "refunded":
        return "Dikembalikan"
      default:
        return status
    }
  }

  if (!user) return null

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="sm" asChild>
              <Link href="/admin/dashboard">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Kembali
              </Link>
            </Button>
            <h1 className="text-2xl font-bold text-gray-900">Manajemen Jadwal Konsultasi</h1>
          </div>
          <div className="flex items-center space-x-4">
            <Button onClick={exportAppointments}>
              <Download className="h-4 w-4 mr-2" />
              Export Data
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Filters */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Filter className="h-5 w-5 mr-2" />
              Filter & Pencarian
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-4 gap-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  placeholder="Cari pasien, dokter, atau jenis..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Filter Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Semua Status</SelectItem>
                  <SelectItem value="pending">Menunggu</SelectItem>
                  <SelectItem value="confirmed">Dikonfirmasi</SelectItem>
                  <SelectItem value="completed">Selesai</SelectItem>
                  <SelectItem value="cancelled">Dibatalkan</SelectItem>
                </SelectContent>
              </Select>
              <Select value={dateFilter} onValueChange={setDateFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Filter Tanggal" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Semua Tanggal</SelectItem>
                  <SelectItem value="today">Hari Ini</SelectItem>
                  <SelectItem value="week">Minggu Ini</SelectItem>
                  <SelectItem value="month">Bulan Ini</SelectItem>
                </SelectContent>
              </Select>
              <Button
                variant="outline"
                onClick={() => {
                  setSearchTerm("")
                  setStatusFilter("all")
                  setDateFilter("all")
                }}
              >
                Reset Filter
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Stats Cards */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Total Jadwal</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{appointments.length}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Menunggu Konfirmasi</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{appointments.filter((a) => a.status === "pending").length}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Dikonfirmasi</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{appointments.filter((a) => a.status === "confirmed").length}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Total Pendapatan</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                Rp{" "}
                {appointments
                  .filter((a) => a.paymentStatus === "paid")
                  .reduce((sum, a) => sum + a.cost, 0)
                  .toLocaleString()}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Appointments List */}
        <div className="space-y-6">
          {filteredAppointments.map((appointment) => (
            <Card key={appointment.id}>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="flex items-center">
                      <Calendar className="h-5 w-5 mr-2" />
                      {appointment.type} - {appointment.patient.name}
                    </CardTitle>
                    <CardDescription>
                      {appointment.doctor.name} • {appointment.doctor.specialty}
                    </CardDescription>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Badge variant={getStatusColor(appointment.status)}>{getStatusText(appointment.status)}</Badge>
                    <Badge variant={getPaymentStatusColor(appointment.paymentStatus)}>
                      {getPaymentStatusText(appointment.paymentStatus)}
                    </Badge>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-4 gap-4 mb-4">
                  <div className="flex items-center space-x-2">
                    <Calendar className="h-4 w-4 text-gray-500" />
                    <span>{new Date(appointment.date).toLocaleDateString("id-ID")}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Clock className="h-4 w-4 text-gray-500" />
                    <span>
                      {appointment.time} ({appointment.duration} menit)
                    </span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <User className="h-4 w-4 text-gray-500" />
                    <span>{appointment.patient.phone}</span>
                  </div>
                  <div>
                    <span className="text-sm text-gray-600">Biaya: </span>
                    <span className="font-semibold">Rp {appointment.cost.toLocaleString()}</span>
                  </div>
                </div>

                {appointment.notes && (
                  <div className="mb-4">
                    <p className="text-sm text-gray-600">
                      <strong>Catatan:</strong> {appointment.notes}
                    </p>
                  </div>
                )}

                <div className="flex justify-end space-x-2">
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button variant="outline" size="sm" onClick={() => setSelectedAppointment(appointment)}>
                        <Eye className="h-4 w-4 mr-2" />
                        Detail
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="sm:max-w-[600px]">
                      <DialogHeader>
                        <DialogTitle>Detail Jadwal Konsultasi</DialogTitle>
                        <DialogDescription>
                          Informasi lengkap jadwal konsultasi #{selectedAppointment?.id}
                        </DialogDescription>
                      </DialogHeader>
                      {selectedAppointment && (
                        <div className="space-y-6">
                          {/* Appointment Info */}
                          <div className="grid md:grid-cols-2 gap-4">
                            <div>
                              <h4 className="font-semibold text-sm text-gray-700 mb-2">Informasi Jadwal</h4>
                              <div className="space-y-2 text-sm">
                                <div className="flex justify-between">
                                  <span className="text-gray-600">ID:</span>
                                  <span className="font-medium">#{selectedAppointment.id}</span>
                                </div>
                                <div className="flex justify-between">
                                  <span className="text-gray-600">Tanggal:</span>
                                  <span className="font-medium">
                                    {new Date(selectedAppointment.date).toLocaleDateString("id-ID")}
                                  </span>
                                </div>
                                <div className="flex justify-between">
                                  <span className="text-gray-600">Waktu:</span>
                                  <span className="font-medium">{selectedAppointment.time}</span>
                                </div>
                                <div className="flex justify-between">
                                  <span className="text-gray-600">Durasi:</span>
                                  <span className="font-medium">{selectedAppointment.duration} menit</span>
                                </div>
                                <div className="flex justify-between">
                                  <span className="text-gray-600">Jenis:</span>
                                  <span className="font-medium">{selectedAppointment.type}</span>
                                </div>
                              </div>
                            </div>
                            <div>
                              <h4 className="font-semibold text-sm text-gray-700 mb-2">Status & Pembayaran</h4>
                              <div className="space-y-2 text-sm">
                                <div className="flex justify-between">
                                  <span className="text-gray-600">Status:</span>
                                  <Badge variant={getStatusColor(selectedAppointment.status)}>
                                    {getStatusText(selectedAppointment.status)}
                                  </Badge>
                                </div>
                                <div className="flex justify-between">
                                  <span className="text-gray-600">Biaya:</span>
                                  <span className="font-medium">Rp {selectedAppointment.cost.toLocaleString()}</span>
                                </div>
                                <div className="flex justify-between">
                                  <span className="text-gray-600">Pembayaran:</span>
                                  <Badge variant={getPaymentStatusColor(selectedAppointment.paymentStatus)}>
                                    {getPaymentStatusText(selectedAppointment.paymentStatus)}
                                  </Badge>
                                </div>
                                <div className="flex justify-between">
                                  <span className="text-gray-600">Dibuat:</span>
                                  <span className="font-medium">
                                    {new Date(selectedAppointment.createdAt).toLocaleDateString("id-ID")}
                                  </span>
                                </div>
                              </div>
                            </div>
                          </div>

                          {/* Patient Info */}
                          <div>
                            <h4 className="font-semibold text-sm text-gray-700 mb-2">Informasi Pasien</h4>
                            <div className="bg-blue-50 p-4 rounded-lg">
                              <div className="grid md:grid-cols-2 gap-4 text-sm">
                                <div>
                                  <p>
                                    <strong>Nama:</strong> {selectedAppointment.patient.name}
                                  </p>
                                  <p>
                                    <strong>Umur:</strong> {selectedAppointment.patient.age} tahun
                                  </p>
                                  <p>
                                    <strong>Kondisi:</strong> {selectedAppointment.patient.condition}
                                  </p>
                                </div>
                                <div>
                                  <p>
                                    <strong>Telepon:</strong> {selectedAppointment.patient.phone}
                                  </p>
                                  <p>
                                    <strong>Email:</strong> {selectedAppointment.patient.email}
                                  </p>
                                </div>
                              </div>
                            </div>
                          </div>

                          {/* Doctor Info */}
                          <div>
                            <h4 className="font-semibold text-sm text-gray-700 mb-2">Informasi Dokter</h4>
                            <div className="bg-green-50 p-4 rounded-lg">
                              <div className="grid md:grid-cols-2 gap-4 text-sm">
                                <div>
                                  <p>
                                    <strong>Nama:</strong> {selectedAppointment.doctor.name}
                                  </p>
                                  <p>
                                    <strong>Spesialisasi:</strong> {selectedAppointment.doctor.specialty}
                                  </p>
                                </div>
                                <div>
                                  <p>
                                    <strong>Telepon:</strong> {selectedAppointment.doctor.phone}
                                  </p>
                                </div>
                              </div>
                            </div>
                          </div>

                          {/* Notes */}
                          {selectedAppointment.notes && (
                            <div>
                              <h4 className="font-semibold text-sm text-gray-700 mb-2">Catatan</h4>
                              <p className="text-sm bg-yellow-50 p-3 rounded-lg">{selectedAppointment.notes}</p>
                            </div>
                          )}
                        </div>
                      )}
                    </DialogContent>
                  </Dialog>

                  {appointment.status === "pending" && (
                    <Button size="sm" onClick={() => updateAppointmentStatus(appointment.id, "confirmed")}>
                      Konfirmasi
                    </Button>
                  )}
                  {appointment.status === "confirmed" && (
                    <Button size="sm" onClick={() => updateAppointmentStatus(appointment.id, "completed")}>
                      Selesai
                    </Button>
                  )}
                  {(appointment.status === "pending" || appointment.status === "confirmed") && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => updateAppointmentStatus(appointment.id, "cancelled")}
                    >
                      Batalkan
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}

          {filteredAppointments.length === 0 && (
            <Card>
              <CardContent className="text-center py-12">
                <Calendar className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">
                  {searchTerm || statusFilter !== "all" || dateFilter !== "all"
                    ? "Tidak Ada Jadwal Ditemukan"
                    : "Belum Ada Jadwal"}
                </h3>
                <p className="text-gray-600">
                  {searchTerm || statusFilter !== "all" || dateFilter !== "all"
                    ? "Coba ubah filter pencarian Anda."
                    : "Jadwal konsultasi akan muncul setelah pasien membuat janji."}
                </p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}
