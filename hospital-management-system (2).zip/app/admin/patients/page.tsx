"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Users, ArrowLeft, Search, Eye, Edit, Trash2, Download } from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"

export default function AdminPatients() {
  const [user, setUser] = useState<any>(null)
  const [patients, setPatients] = useState<any[]>([])
  const [filteredPatients, setFilteredPatients] = useState<any[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedPatient, setSelectedPatient] = useState<any>(null)
  const [isEditModalOpen, setIsEditModalOpen] = useState(false)
  const [editingPatient, setEditingPatient] = useState<any>(null)
  const router = useRouter()

  useEffect(() => {
    const userData = localStorage.getItem("user")
    if (userData) {
      const parsedUser = JSON.parse(userData)
      if (parsedUser.role !== "admin") {
        router.push("/login")
      } else {
        setUser(parsedUser)
        loadPatients()
      }
    } else {
      router.push("/login")
    }
  }, [router])

  useEffect(() => {
    const filtered = patients.filter(
      (patient) =>
        patient.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        patient.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
        patient.phone.includes(searchTerm),
    )
    setFilteredPatients(filtered)
  }, [searchTerm, patients])

  const loadPatients = () => {
    // Mock data - replace with actual API call
    const mockPatients = [
      {
        id: 1,
        name: "John Doe",
        email: "john.doe@email.com",
        phone: "081234567890",
        age: 34,
        gender: "Laki-laki",
        address: "Jl. Sudirman No. 123, Jakarta",
        bloodType: "O+",
        registrationDate: "2024-01-01",
        lastVisit: "2024-01-10",
        totalVisits: 5,
        status: "active",
        emergencyContact: "Jane Doe - 081234567891",
        allergies: "Tidak ada",
      },
      {
        id: 2,
        name: "Maria Santos",
        email: "maria.santos@email.com",
        phone: "081234567892",
        age: 28,
        gender: "Perempuan",
        address: "Jl. Thamrin No. 456, Jakarta",
        bloodType: "A+",
        registrationDate: "2024-01-15",
        lastVisit: "2024-01-08",
        totalVisits: 3,
        status: "active",
        emergencyContact: "Carlos Santos - 081234567893",
        allergies: "Penisilin",
      },
      {
        id: 3,
        name: "Ahmad Wijaya",
        email: "ahmad.wijaya@email.com",
        phone: "081234567894",
        age: 45,
        gender: "Laki-laki",
        address: "Jl. Gatot Subroto No. 789, Jakarta",
        bloodType: "B+",
        registrationDate: "2023-12-20",
        lastVisit: "2024-01-05",
        totalVisits: 8,
        status: "active",
        emergencyContact: "Siti Wijaya - 081234567895",
        allergies: "Tidak ada",
      },
      {
        id: 4,
        name: "Lisa Chen",
        email: "lisa.chen@email.com",
        phone: "081234567896",
        age: 31,
        gender: "Perempuan",
        address: "Jl. Kuningan No. 321, Jakarta",
        bloodType: "AB+",
        registrationDate: "2024-01-20",
        lastVisit: null,
        totalVisits: 0,
        status: "inactive",
        emergencyContact: "David Chen - 081234567897",
        allergies: "Seafood",
      },
    ]
    setPatients(mockPatients)
    setFilteredPatients(mockPatients)
  }

  const updatePatient = () => {
    if (editingPatient) {
      const updatedPatients = patients.map((p) => (p.id === editingPatient.id ? editingPatient : p))
      setPatients(updatedPatients)
      setFilteredPatients(updatedPatients)
      setIsEditModalOpen(false)
      setEditingPatient(null)
      alert("Data pasien berhasil diperbarui!")
    }
  }

  const deletePatient = (patientId: number) => {
    if (confirm("Apakah Anda yakin ingin menghapus data pasien ini?")) {
      const updatedPatients = patients.filter((p) => p.id !== patientId)
      setPatients(updatedPatients)
      setFilteredPatients(updatedPatients)
      alert("Data pasien berhasil dihapus!")
    }
  }

  const exportPatientData = () => {
    const csvContent = [
      [
        "Nama",
        "Email",
        "Telepon",
        "Umur",
        "Jenis Kelamin",
        "Golongan Darah",
        "Tanggal Daftar",
        "Kunjungan Terakhir",
        "Total Kunjungan",
        "Status",
      ],
      ...patients.map((p) => [
        p.name,
        p.email,
        p.phone,
        p.age,
        p.gender,
        p.bloodType,
        p.registrationDate,
        p.lastVisit || "Belum pernah",
        p.totalVisits,
        p.status,
      ]),
    ]
      .map((row) => row.join(","))
      .join("\n")

    const blob = new Blob([csvContent], { type: "text/csv" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `data-pasien-${new Date().toISOString().split("T")[0]}.csv`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  const getStatusColor = (status: string) => {
    return status === "active" ? "default" : "secondary"
  }

  const getStatusText = (status: string) => {
    return status === "active" ? "Aktif" : "Tidak Aktif"
  }

  if (!user) return null

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="sm" asChild>
              <Link href="/admin/dashboard">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Kembali
              </Link>
            </Button>
            <h1 className="text-2xl font-bold text-gray-900">Manajemen Pasien</h1>
          </div>
          <div className="flex items-center space-x-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="Cari pasien..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 w-64"
              />
            </div>
            <Button onClick={exportPatientData}>
              <Download className="h-4 w-4 mr-2" />
              Export Data
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Stats Cards */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Total Pasien</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{patients.length}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Pasien Aktif</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{patients.filter((p) => p.status === "active").length}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Pasien Baru (Bulan Ini)</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {patients.filter((p) => new Date(p.registrationDate).getMonth() === new Date().getMonth()).length}
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Total Kunjungan</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{patients.reduce((sum, p) => sum + p.totalVisits, 0)}</div>
            </CardContent>
          </Card>
        </div>

        {/* Patients List */}
        <div className="space-y-6">
          {filteredPatients.map((patient) => (
            <Card key={patient.id}>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="flex items-center">
                      <Users className="h-5 w-5 mr-2" />
                      {patient.name}
                    </CardTitle>
                    <CardDescription>
                      {patient.age} tahun • {patient.gender} • {patient.email}
                    </CardDescription>
                  </div>
                  <Badge variant={getStatusColor(patient.status)}>{getStatusText(patient.status)}</Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-4 gap-4 mb-4">
                  <div>
                    <p className="text-sm text-gray-600">Telepon</p>
                    <p className="font-semibold">{patient.phone}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Golongan Darah</p>
                    <p className="font-semibold">{patient.bloodType}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Tanggal Daftar</p>
                    <p className="font-semibold">{new Date(patient.registrationDate).toLocaleDateString("id-ID")}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Total Kunjungan</p>
                    <p className="font-semibold">{patient.totalVisits} kali</p>
                  </div>
                </div>

                <div className="flex justify-end space-x-2">
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button variant="outline" size="sm" onClick={() => setSelectedPatient(patient)}>
                        <Eye className="h-4 w-4 mr-2" />
                        Detail
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="sm:max-w-[600px]">
                      <DialogHeader>
                        <DialogTitle>Detail Pasien - {selectedPatient?.name}</DialogTitle>
                        <DialogDescription>Informasi lengkap pasien</DialogDescription>
                      </DialogHeader>
                      {selectedPatient && (
                        <div className="space-y-4">
                          <div className="grid md:grid-cols-2 gap-4">
                            <div>
                              <h4 className="font-semibold text-sm text-gray-700 mb-2">Informasi Pribadi</h4>
                              <div className="space-y-1 text-sm">
                                <p>
                                  <strong>Nama:</strong> {selectedPatient.name}
                                </p>
                                <p>
                                  <strong>Email:</strong> {selectedPatient.email}
                                </p>
                                <p>
                                  <strong>Telepon:</strong> {selectedPatient.phone}
                                </p>
                                <p>
                                  <strong>Umur:</strong> {selectedPatient.age} tahun
                                </p>
                                <p>
                                  <strong>Jenis Kelamin:</strong> {selectedPatient.gender}
                                </p>
                                <p>
                                  <strong>Golongan Darah:</strong> {selectedPatient.bloodType}
                                </p>
                              </div>
                            </div>
                            <div>
                              <h4 className="font-semibold text-sm text-gray-700 mb-2">Informasi Medis</h4>
                              <div className="space-y-1 text-sm">
                                <p>
                                  <strong>Alergi:</strong> {selectedPatient.allergies}
                                </p>
                                <p>
                                  <strong>Kontak Darurat:</strong> {selectedPatient.emergencyContact}
                                </p>
                                <p>
                                  <strong>Tanggal Daftar:</strong>{" "}
                                  {new Date(selectedPatient.registrationDate).toLocaleDateString("id-ID")}
                                </p>
                                <p>
                                  <strong>Kunjungan Terakhir:</strong>{" "}
                                  {selectedPatient.lastVisit
                                    ? new Date(selectedPatient.lastVisit).toLocaleDateString("id-ID")
                                    : "Belum pernah"}
                                </p>
                                <p>
                                  <strong>Total Kunjungan:</strong> {selectedPatient.totalVisits} kali
                                </p>
                              </div>
                            </div>
                          </div>
                          <div>
                            <h4 className="font-semibold text-sm text-gray-700 mb-2">Alamat</h4>
                            <p className="text-sm">{selectedPatient.address}</p>
                          </div>
                        </div>
                      )}
                    </DialogContent>
                  </Dialog>

                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      setEditingPatient({ ...patient })
                      setIsEditModalOpen(true)
                    }}
                  >
                    <Edit className="h-4 w-4 mr-2" />
                    Edit
                  </Button>

                  <Button variant="outline" size="sm" onClick={() => deletePatient(patient.id)}>
                    <Trash2 className="h-4 w-4 mr-2" />
                    Hapus
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}

          {filteredPatients.length === 0 && (
            <Card>
              <CardContent className="text-center py-12">
                <Users className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">
                  {searchTerm ? "Pasien Tidak Ditemukan" : "Belum Ada Data Pasien"}
                </h3>
                <p className="text-gray-600">
                  {searchTerm
                    ? "Coba gunakan kata kunci pencarian yang berbeda."
                    : "Data pasien akan muncul setelah ada registrasi."}
                </p>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Edit Patient Modal */}
        <Dialog open={isEditModalOpen} onOpenChange={setIsEditModalOpen}>
          <DialogContent className="sm:max-w-[500px]">
            <DialogHeader>
              <DialogTitle>Edit Data Pasien</DialogTitle>
              <DialogDescription>Perbarui informasi pasien</DialogDescription>
            </DialogHeader>
            {editingPatient && (
              <div className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Nama Lengkap</Label>
                    <Input
                      id="name"
                      value={editingPatient.name}
                      onChange={(e) => setEditingPatient({ ...editingPatient, name: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      value={editingPatient.email}
                      onChange={(e) => setEditingPatient({ ...editingPatient, email: e.target.value })}
                    />
                  </div>
                </div>
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="phone">Telepon</Label>
                    <Input
                      id="phone"
                      value={editingPatient.phone}
                      onChange={(e) => setEditingPatient({ ...editingPatient, phone: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="age">Umur</Label>
                    <Input
                      id="age"
                      type="number"
                      value={editingPatient.age}
                      onChange={(e) => setEditingPatient({ ...editingPatient, age: Number.parseInt(e.target.value) })}
                    />
                  </div>
                </div>
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="gender">Jenis Kelamin</Label>
                    <Select
                      value={editingPatient.gender}
                      onValueChange={(value) => setEditingPatient({ ...editingPatient, gender: value })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Laki-laki">Laki-laki</SelectItem>
                        <SelectItem value="Perempuan">Perempuan</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="bloodType">Golongan Darah</Label>
                    <Select
                      value={editingPatient.bloodType}
                      onValueChange={(value) => setEditingPatient({ ...editingPatient, bloodType: value })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="A+">A+</SelectItem>
                        <SelectItem value="A-">A-</SelectItem>
                        <SelectItem value="B+">B+</SelectItem>
                        <SelectItem value="B-">B-</SelectItem>
                        <SelectItem value="AB+">AB+</SelectItem>
                        <SelectItem value="AB-">AB-</SelectItem>
                        <SelectItem value="O+">O+</SelectItem>
                        <SelectItem value="O-">O-</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="address">Alamat</Label>
                  <Textarea
                    id="address"
                    value={editingPatient.address}
                    onChange={(e) => setEditingPatient({ ...editingPatient, address: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="emergencyContact">Kontak Darurat</Label>
                  <Input
                    id="emergencyContact"
                    value={editingPatient.emergencyContact}
                    onChange={(e) => setEditingPatient({ ...editingPatient, emergencyContact: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="allergies">Alergi</Label>
                  <Input
                    id="allergies"
                    value={editingPatient.allergies}
                    onChange={(e) => setEditingPatient({ ...editingPatient, allergies: e.target.value })}
                  />
                </div>
                <div className="flex justify-end space-x-2">
                  <Button variant="outline" onClick={() => setIsEditModalOpen(false)}>
                    Batal
                  </Button>
                  <Button onClick={updatePatient}>Simpan Perubahan</Button>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </div>
  )
}
