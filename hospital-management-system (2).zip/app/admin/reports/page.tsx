"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  FileText,
  ArrowLeft,
  Download,
  TrendingUp,
  Users,
  Calendar,
  DollarSign,
  Activity,
  BarChart3,
  PieChart,
} from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"

export default function AdminReports() {
  const [user, setUser] = useState<any>(null)
  const [selectedPeriod, setSelectedPeriod] = useState("month")
  const [selectedReport, setSelectedReport] = useState("overview")
  const router = useRouter()

  useEffect(() => {
    const userData = localStorage.getItem("user")
    if (userData) {
      const parsedUser = JSON.parse(userData)
      if (parsedUser.role !== "admin") {
        router.push("/login")
      } else {
        setUser(parsedUser)
      }
    } else {
      router.push("/login")
    }
  }, [router])

  const generateReport = (reportType: string) => {
    // Mock report generation
    const reportData = getReportData(reportType)
    const csvContent = generateCSV(reportData, reportType)

    const blob = new Blob([csvContent], { type: "text/csv" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `laporan-${reportType}-${selectedPeriod}-${new Date().toISOString().split("T")[0]}.csv`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)

    alert(`Laporan ${reportType} berhasil diunduh!`)
  }

  const getReportData = (reportType: string) => {
    // Mock data based on report type
    switch (reportType) {
      case "financial":
        return {
          totalRevenue: 125000000,
          consultationRevenue: 85000000,
          medicineRevenue: 40000000,
          expenses: 45000000,
          profit: 80000000,
          transactions: [
            { date: "2024-01-01", amount: 500000, type: "Konsultasi", patient: "John Doe" },
            { date: "2024-01-02", amount: 350000, type: "Konsultasi", patient: "Maria Santos" },
            { date: "2024-01-03", amount: 450000, type: "Konsultasi", patient: "Ahmad Wijaya" },
          ],
        }
      case "patient":
        return {
          totalPatients: 1234,
          newPatients: 156,
          activePatients: 890,
          patientsByAge: {
            "0-18": 123,
            "19-35": 456,
            "36-50": 345,
            "51+": 310,
          },
          patientsByGender: {
            male: 567,
            female: 667,
          },
        }
      case "doctor":
        return {
          totalDoctors: 28,
          activeDoctors: 25,
          consultationsPerDoctor: {
            "Dr. Sarah Johnson": 245,
            "Dr. Michael Chen": 189,
            "Dr. Lisa Wong": 156,
            "Dr. Ahmad Rizki": 312,
          },
          averageRating: 4.7,
        }
      default:
        return {}
    }
  }

  const generateCSV = (data: any, reportType: string) => {
    switch (reportType) {
      case "financial":
        return [
          ["Jenis", "Jumlah"],
          ["Total Pendapatan", `Rp ${data.totalRevenue.toLocaleString()}`],
          ["Pendapatan Konsultasi", `Rp ${data.consultationRevenue.toLocaleString()}`],
          ["Pendapatan Obat", `Rp ${data.medicineRevenue.toLocaleString()}`],
          ["Total Pengeluaran", `Rp ${data.expenses.toLocaleString()}`],
          ["Keuntungan Bersih", `Rp ${data.profit.toLocaleString()}`],
        ]
          .map((row) => row.join(","))
          .join("\n")

      case "patient":
        return [
          ["Kategori", "Jumlah"],
          ["Total Pasien", data.totalPatients],
          ["Pasien Baru", data.newPatients],
          ["Pasien Aktif", data.activePatients],
          ["Laki-laki", data.patientsByGender.male],
          ["Perempuan", data.patientsByGender.female],
        ]
          .map((row) => row.join(","))
          .join("\n")

      default:
        return "Data,Nilai\nTidak ada data,0"
    }
  }

  if (!user) return null

  // Mock data for charts and statistics
  const overviewStats = [
    {
      title: "Total Pendapatan",
      value: "Rp 125M",
      change: "+18%",
      icon: DollarSign,
      color: "text-green-600",
    },
    {
      title: "Total Pasien",
      value: "1,234",
      change: "+12%",
      icon: Users,
      color: "text-blue-600",
    },
    {
      title: "Konsultasi Bulan Ini",
      value: "456",
      change: "+8%",
      icon: Calendar,
      color: "text-purple-600",
    },
    {
      title: "Tingkat Kepuasan",
      value: "4.8/5",
      change: "+0.2",
      icon: Activity,
      color: "text-orange-600",
    },
  ]

  const monthlyData = [
    { month: "Jan", revenue: 8500000, patients: 89, consultations: 234 },
    { month: "Feb", revenue: 9200000, patients: 95, consultations: 267 },
    { month: "Mar", revenue: 10100000, patients: 108, consultations: 289 },
    { month: "Apr", revenue: 11500000, patients: 123, consultations: 312 },
    { month: "May", revenue: 12800000, patients: 134, consultations: 345 },
    { month: "Jun", revenue: 13200000, patients: 145, consultations: 378 },
  ]

  const topDoctors = [
    { name: "Dr. Sarah Johnson", specialty: "Kardiologi", patients: 245, revenue: 122500000, rating: 4.9 },
    { name: "Dr. Ahmad Rizki", specialty: "Penyakit Dalam", patients: 312, revenue: 140400000, rating: 4.6 },
    { name: "Dr. Michael Chen", specialty: "Dermatologi", patients: 189, revenue: 75600000, rating: 4.7 },
    { name: "Dr. Lisa Wong", specialty: "Gizi", patients: 156, revenue: 54600000, rating: 4.9 },
  ]

  const patientDemographics = [
    { ageGroup: "0-18 tahun", count: 123, percentage: 10 },
    { ageGroup: "19-35 tahun", count: 456, percentage: 37 },
    { ageGroup: "36-50 tahun", count: 345, percentage: 28 },
    { ageGroup: "51+ tahun", count: 310, percentage: 25 },
  ]

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="sm" asChild>
              <Link href="/admin/dashboard">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Kembali
              </Link>
            </Button>
            <h1 className="text-2xl font-bold text-gray-900">Laporan & Analitik</h1>
          </div>
          <div className="flex items-center space-x-4">
            <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
              <SelectTrigger className="w-40">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="week">Minggu Ini</SelectItem>
                <SelectItem value="month">Bulan Ini</SelectItem>
                <SelectItem value="quarter">Kuartal Ini</SelectItem>
                <SelectItem value="year">Tahun Ini</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Overview Stats */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {overviewStats.map((stat, index) => (
            <Card key={index}>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">{stat.title}</CardTitle>
                <stat.icon className={`h-4 w-4 ${stat.color}`} />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stat.value}</div>
                <p className="text-xs text-muted-foreground">
                  <span className="text-green-600">{stat.change}</span> dari periode sebelumnya
                </p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Report Sections */}
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Financial Report */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center">
                    <BarChart3 className="h-5 w-5 mr-2" />
                    Laporan Keuangan
                  </CardTitle>
                  <CardDescription>Analisis pendapatan dan pengeluaran</CardDescription>
                </div>
                <Button onClick={() => generateReport("financial")}>
                  <Download className="h-4 w-4 mr-2" />
                  Export
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {/* Revenue Chart Placeholder */}
                <div className="h-64 bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg flex items-center justify-center">
                  <div className="text-center">
                    <TrendingUp className="h-16 w-16 text-blue-500 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-gray-700">Grafik Pendapatan Bulanan</h3>
                    <p className="text-sm text-gray-500">Tren pendapatan 6 bulan terakhir</p>
                  </div>
                </div>

                {/* Monthly Data Table */}
                <div>
                  <h4 className="font-semibold mb-3">Data Bulanan</h4>
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="border-b">
                          <th className="text-left p-2">Bulan</th>
                          <th className="text-right p-2">Pendapatan</th>
                          <th className="text-right p-2">Pasien Baru</th>
                          <th className="text-right p-2">Konsultasi</th>
                        </tr>
                      </thead>
                      <tbody>
                        {monthlyData.map((data, index) => (
                          <tr key={index} className="border-b">
                            <td className="p-2 font-medium">{data.month}</td>
                            <td className="p-2 text-right">Rp {data.revenue.toLocaleString()}</td>
                            <td className="p-2 text-right">{data.patients}</td>
                            <td className="p-2 text-right">{data.consultations}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Quick Reports */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <FileText className="h-5 w-5 mr-2" />
                Laporan Cepat
              </CardTitle>
              <CardDescription>Download laporan dalam berbagai format</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <Button variant="outline" className="w-full justify-start" onClick={() => generateReport("financial")}>
                  <DollarSign className="h-4 w-4 mr-2" />
                  Laporan Keuangan
                </Button>
                <Button variant="outline" className="w-full justify-start" onClick={() => generateReport("patient")}>
                  <Users className="h-4 w-4 mr-2" />
                  Laporan Pasien
                </Button>
                <Button variant="outline" className="w-full justify-start" onClick={() => generateReport("doctor")}>
                  <Activity className="h-4 w-4 mr-2" />
                  Laporan Dokter
                </Button>
                <Button
                  variant="outline"
                  className="w-full justify-start"
                  onClick={() => generateReport("appointment")}
                >
                  <Calendar className="h-4 w-4 mr-2" />
                  Laporan Jadwal
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Doctor Performance */}
        <Card className="mt-8">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="flex items-center">
                  <Activity className="h-5 w-5 mr-2" />
                  Performa Dokter
                </CardTitle>
                <CardDescription>Statistik kinerja dokter berdasarkan periode yang dipilih</CardDescription>
              </div>
              <Button onClick={() => generateReport("doctor")}>
                <Download className="h-4 w-4 mr-2" />
                Export
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b">
                    <th className="text-left p-3">Dokter</th>
                    <th className="text-left p-3">Spesialisasi</th>
                    <th className="text-right p-3">Total Pasien</th>
                    <th className="text-right p-3">Pendapatan</th>
                    <th className="text-right p-3">Rating</th>
                    <th className="text-center p-3">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {topDoctors.map((doctor, index) => (
                    <tr key={index} className="border-b hover:bg-gray-50">
                      <td className="p-3 font-medium">{doctor.name}</td>
                      <td className="p-3 text-gray-600">{doctor.specialty}</td>
                      <td className="p-3 text-right">{doctor.patients}</td>
                      <td className="p-3 text-right">Rp {doctor.revenue.toLocaleString()}</td>
                      <td className="p-3 text-right">⭐ {doctor.rating}</td>
                      <td className="p-3 text-center">
                        <Badge variant="default">Aktif</Badge>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        {/* Patient Demographics */}
        <Card className="mt-8">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="flex items-center">
                  <PieChart className="h-5 w-5 mr-2" />
                  Demografi Pasien
                </CardTitle>
                <CardDescription>Distribusi pasien berdasarkan kelompok usia</CardDescription>
              </div>
              <Button onClick={() => generateReport("patient")}>
                <Download className="h-4 w-4 mr-2" />
                Export
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-8">
              {/* Age Distribution Chart Placeholder */}
              <div className="h-64 bg-gradient-to-r from-green-50 to-blue-50 rounded-lg flex items-center justify-center">
                <div className="text-center">
                  <PieChart className="h-16 w-16 text-green-500 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-gray-700">Distribusi Usia</h3>
                  <p className="text-sm text-gray-500">Grafik pie chart demografi pasien</p>
                </div>
              </div>

              {/* Demographics Table */}
              <div>
                <h4 className="font-semibold mb-4">Distribusi Kelompok Usia</h4>
                <div className="space-y-3">
                  {patientDemographics.map((demo, index) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div>
                        <span className="font-medium">{demo.ageGroup}</span>
                        <div className="text-sm text-gray-600">{demo.count} pasien</div>
                      </div>
                      <div className="text-right">
                        <div className="font-semibold">{demo.percentage}%</div>
                        <div className="w-20 bg-gray-200 rounded-full h-2 mt-1">
                          <div className="bg-blue-600 h-2 rounded-full" style={{ width: `${demo.percentage}%` }}></div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Summary Cards */}
        <div className="grid md:grid-cols-3 gap-6 mt-8">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Ringkasan Keuangan</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-gray-600">Total Pendapatan:</span>
                  <span className="font-semibold">Rp 125M</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Total Pengeluaran:</span>
                  <span className="font-semibold">Rp 45M</span>
                </div>
                <div className="flex justify-between border-t pt-2">
                  <span className="text-gray-600">Keuntungan Bersih:</span>
                  <span className="font-semibold text-green-600">Rp 80M</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Aktivitas Pasien</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-gray-600">Pasien Aktif:</span>
                  <span className="font-semibold">890</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Pasien Baru:</span>
                  <span className="font-semibold">156</span>
                </div>
                <div className="flex justify-between border-t pt-2">
                  <span className="text-gray-600">Total Konsultasi:</span>
                  <span className="font-semibold text-blue-600">2,456</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Kualitas Layanan</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-gray-600">Rating Rata-rata:</span>
                  <span className="font-semibold">⭐ 4.8</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Tingkat Kepuasan:</span>
                  <span className="font-semibold">96%</span>
                </div>
                <div className="flex justify-between border-t pt-2">
                  <span className="text-gray-600">Keluhan:</span>
                  <span className="font-semibold text-orange-600">12</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
