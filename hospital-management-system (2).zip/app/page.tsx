import { Button } from "@/components/ui/button"
import { Card, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Calendar, FileText, CreditCard, Users, Shield, Heart } from "lucide-react"
import Link from "next/link"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-white">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <img src="/images/hospital-logo.png" alt="PERSADA SARI HUSNA Medical Center" className="h-12 w-12" />
            <span className="text-2xl font-bold text-gray-900">PERSADA SARI HUSNA</span>
            <span className="text-sm text-gray-600">Medical Center</span>
          </div>
          <div className="flex space-x-4">
            <Button variant="outline" asChild>
              <Link href="/login">Masuk</Link>
            </Button>
            <Button asChild>
              <Link href="/register">Daftar</Link>
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto text-center">
          <h1 className="text-5xl font-bold text-gray-900 mb-6">Layanan Kesehatan Digital Terdepan</h1>
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
            Sistem pelayanan rumah sakit online yang terintegrasi dengan teknologi cloud. Daftar online, jadwal dokter,
            rekam medis elektronik, dan pembayaran digital dalam satu platform.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" asChild>
              <Link href="/register">Daftar Sebagai Pasien</Link>
            </Button>
            <Button size="lg" variant="outline" asChild>
              <Link href="/login">Portal Admin</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 px-4 bg-white">
        <div className="container mx-auto">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">Fitur Unggulan Sistem Kami</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <Users className="h-12 w-12 text-blue-600 mb-4" />
                <CardTitle>Pendaftaran Online</CardTitle>
                <CardDescription>Daftar sebagai pasien baru atau jadwalkan kunjungan dengan mudah</CardDescription>
              </CardHeader>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <Calendar className="h-12 w-12 text-green-600 mb-4" />
                <CardTitle>Jadwal Dokter</CardTitle>
                <CardDescription>Lihat jadwal dokter dan buat janji temu sesuai kebutuhan Anda</CardDescription>
              </CardHeader>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <FileText className="h-12 w-12 text-purple-600 mb-4" />
                <CardTitle>Rekam Medis Elektronik</CardTitle>
                <CardDescription>Akses riwayat kesehatan dan rekam medis digital yang aman</CardDescription>
              </CardHeader>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <CreditCard className="h-12 w-12 text-orange-600 mb-4" />
                <CardTitle>Pembayaran Digital</CardTitle>
                <CardDescription>Bayar biaya layanan dengan transfer bank atau QRIS</CardDescription>
              </CardHeader>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <Shield className="h-12 w-12 text-red-600 mb-4" />
                <CardTitle>Keamanan Data</CardTitle>
                <CardDescription>Data pasien dilindungi dengan enkripsi tingkat enterprise</CardDescription>
              </CardHeader>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <Heart className="h-12 w-12 text-pink-600 mb-4" />
                <CardTitle>Layanan 24/7</CardTitle>
                <CardDescription>Akses sistem kapan saja dengan dukungan cloud infrastructure</CardDescription>
              </CardHeader>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 px-4 bg-blue-600 text-white">
        <div className="container mx-auto text-center">
          <h2 className="text-3xl font-bold mb-6">Mulai Gunakan Layanan Digital Kami</h2>
          <p className="text-xl mb-8 opacity-90">
            Bergabunglah dengan ribuan pasien yang telah merasakan kemudahan layanan kesehatan digital
          </p>
          <Button size="lg" variant="secondary" asChild>
            <Link href="/register">Daftar Sekarang</Link>
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12 px-4">
        <div className="container mx-auto">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <img src="/images/hospital-logo.png" alt="PERSADA SARI HUSNA Medical Center" className="h-8 w-8" />
                <span className="text-lg font-semibold">PERSADA SARI HUSNA Medical Center</span>
              </div>
              <p className="text-gray-400">
                Sistem pelayanan rumah sakit online terpercaya dengan teknologi cloud terdepan.
              </p>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Layanan</h3>
              <ul className="space-y-2 text-gray-400">
                <li>Pendaftaran Online</li>
                <li>Jadwal Dokter</li>
                <li>Rekam Medis</li>
                <li>Pembayaran Digital</li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Kontak</h3>
              <ul className="space-y-2 text-gray-400">
                <li>Email: info@persadasarihusna.co.id</li>
                <li>Telepon: (021) 2345-6789</li>
                <li>WhatsApp: +62 813-4567-8901</li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Alamat</h3>
              <p className="text-gray-400">
                Jl. Kesehatan Persada No. 456
                <br />
                Jakarta Selatan 12160
                <br />
                Indonesia
              </p>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 PERSADA SARI HUSNA Medical Center. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
